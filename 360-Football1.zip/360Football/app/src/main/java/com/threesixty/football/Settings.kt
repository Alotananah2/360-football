package com.threesixty.football

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

class FootballApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Settings.init(this)
        Net.init(this)
        Images.init(this)
    }
}

object Settings {
    /** TheSportsDB's free public key. A Patreon key unlocks fuller data. */
    const val DEFAULT_KEY = "123"

    private lateinit var prefs: SharedPreferences

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
    }

    var apiKey: String
        get() = prefs.getString("api_key", null)?.trim()?.takeIf { it.isNotEmpty() } ?: DEFAULT_KEY
        set(value) {
            prefs.edit().putString("api_key", value.trim()).apply()
        }

    var league: String
        get() = prefs.getString("league", null) ?: Leagues.all.first().id
        set(value) {
            prefs.edit().putString("league", value).apply()
        }

    var tab: Int
        get() = prefs.getInt("tab", 0)
        set(value) {
            prefs.edit().putInt("tab", value).apply()
        }

    var showResults: Boolean
        get() = prefs.getBoolean("results", false)
        set(value) {
            prefs.edit().putBoolean("results", value).apply()
        }

    var favouritesJson: String
        get() = prefs.getString("favs", null) ?: "[]"
        set(value) {
            prefs.edit().putString("favs", value).apply()
        }
}

object Favourites {
    fun all(): List<Team> {
        val arr = try {
            JSONArray(Settings.favouritesJson)
        } catch (e: JSONException) {
            JSONArray()
        }
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }.mapNotNull { o ->
            val id = o.str("id") ?: return@mapNotNull null
            Team(id, o.str("name") ?: id, o.str("badge"))
        }
    }

    fun contains(id: String): Boolean = all().any { it.id == id }

    /** Returns true if the team was added, false if removed. */
    fun toggle(team: Team): Boolean {
        val list = all().toMutableList()
        val added = list.none { it.id == team.id }
        if (added) list.add(team) else list.removeAll { it.id == team.id }
        val arr = JSONArray()
        list.forEach { t ->
            arr.put(JSONObject().put("id", t.id).put("name", t.name).put("badge", t.badge ?: ""))
        }
        Settings.favouritesJson = arr.toString()
        return added
    }
}
