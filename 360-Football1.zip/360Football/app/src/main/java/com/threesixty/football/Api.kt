package com.threesixty.football

import org.json.JSONException
import org.json.JSONObject
import java.net.URLEncoder
import java.time.Instant
import java.util.concurrent.ConcurrentHashMap

/**
 * TheSportsDB v1 API (https://www.thesportsdb.com).
 *
 * The free plan is strict: ~10 requests a minute, and "next/last matches", tables and team lists
 * are cut to a handful of rows. Whole matchdays ("rounds") come back complete, so fixtures,
 * results, the club list and the league table are all built from rounds, which are cached.
 */
object Api {
    private const val BASE = "https://www.thesportsdb.com/api/v1/json/"
    private const val SHORT = 5 * 60_000L
    private const val HALF_HOUR = 30 * 60_000L
    private const val DAY = 24 * 60 * 60_000L

    /** Rounds numbered this high are knockout stages in cup competitions. */
    private const val KNOCKOUT = 100

    private val badges = ConcurrentHashMap<String, String>()
    private val matches = ConcurrentHashMap<String, Match>()

    fun badge(teamId: String?): String? = teamId?.let { badges[it] }

    /** A match we've already loaded (saves a request when opening it). */
    fun knownMatch(id: String): Match? = matches[id]

    private fun url(path: String) = BASE + Settings.apiKey + "/" + path
    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun parse(body: String, keys: Array<out String>): List<JSONObject> {
        val root = try {
            JSONObject(body)
        } catch (e: JSONException) {
            return emptyList()
        }
        for (k in keys) {
            val arr = root.optJSONArray(k) ?: continue
            return (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
        }
        return emptyList()
    }

    private suspend fun fetch(path: String, ttl: Long, force: Boolean, vararg keys: String): List<JSONObject> =
        parse(Net.get(url(path), ttl, force), keys)

    private fun remember(list: List<Match>): List<Match> {
        list.forEach { m ->
            matches[m.id] = m
            val hid = m.homeId
            val aid = m.awayId
            val hb = m.homeBadge
            val ab = m.awayBadge
            if (hid != null && hb != null) badges[hid] = hb
            if (aid != null && ab != null) badges[aid] = ab
        }
        return list
    }

    private suspend fun events(path: String, ttl: Long, force: Boolean): List<Match> =
        remember(fetch(path, ttl, force, "events", "results", "event").mapNotNull { Match.from(it) })

    // ------------------------------------------------------------------ rounds

    data class RoundInfo(val round: Int, val season: String)

    /** Which matchday the league is on, from its next and most recent match. */
    suspend fun currentRound(league: League, force: Boolean): RoundInfo? {
        val next = events("eventsnextleague.php?id=${league.id}", HALF_HOUR, force).firstOrNull()
        val past = events("eventspastleague.php?id=${league.id}", HALF_HOUR, force).firstOrNull()
        val candidates = listOfNotNull(next, past).filter { it.round?.toIntOrNull() != null }
        if (candidates.isEmpty()) return null
        // A postponed game from an old round can show up as "next", so take the later round,
        // but don't let a knockout code jump ahead of a league round still being played.
        val best = candidates.maxByOrNull { it.round?.toIntOrNull() ?: 0 } ?: return null
        val round = best.round?.toIntOrNull() ?: return null
        return RoundInfo(round, best.season ?: league.season())
    }

    /** One whole matchday. Finished rounds are kept for good; current ones refresh every 5 minutes. */
    suspend fun round(league: League, round: Int, season: String, force: Boolean): List<Match> {
        if (round <= 0) return emptyList()
        val path = "eventsround.php?id=${league.id}&r=$round&s=$season"
        val cached = Net.peek(url(path))
        if (cached != null) {
            val list = parse(cached, arrayOf("events")).mapNotNull { Match.from(it) }
            if (list.isNotEmpty() && list.all { it.isFinished || it.isPostponed }) return remember(list)
        }
        return events(path, SHORT, force)
    }

    suspend fun upcoming(league: League, force: Boolean): List<Match> {
        val info = currentRound(league, force) ?: return emptyList()
        val cutoff = Instant.now().minusSeconds(3 * 3600L)
        val list = round(league, info.round, info.season, force) +
            round(league, info.round + 1, info.season, force)
        return list.distinctBy { it.id }
            .filter { m -> !m.isFinished && !m.isPostponed && (m.kickoff?.isAfter(cutoff) ?: true) }
            .sortedBy { it.sortKey }
    }

    suspend fun results(league: League, force: Boolean): List<Match> {
        val info = currentRound(league, force) ?: return emptyList()
        val list = round(league, info.round, info.season, force) +
            round(league, info.round - 1, info.season, force)
        return list.distinctBy { it.id }.filter { it.hasScore }.sortedByDescending { it.sortKey }
    }

    /** Every club, taken from the current and previous matchday (each club plays once per round). */
    suspend fun teams(league: League, force: Boolean): List<Team> {
        val info = currentRound(league, force) ?: return emptyList()
        var rounds = round(league, info.round, info.season, force)
        if (info.round > 1) rounds = rounds + round(league, info.round - 1, info.season, force)
        val found = LinkedHashMap<String, Team>()
        for (m in rounds) {
            val hid = m.homeId
            val aid = m.awayId
            if (hid != null && !found.containsKey(hid)) found[hid] = Team(hid, m.home, m.homeBadge ?: badges[hid])
            if (aid != null && !found.containsKey(aid)) found[aid] = Team(aid, m.away, m.awayBadge ?: badges[aid])
        }
        return found.values.sortedBy { it.name.lowercase() }
    }

    /**
     * The free plan's table only lists the top 5, so the full table is worked out from every
     * matchday's results. Past matchdays are cached, so only the first build takes a while.
     */
    suspend fun table(league: League, force: Boolean, progress: (Int, Int) -> Unit): List<Standing> {
        val info = currentRound(league, force) ?: return emptyList()
        val last = if (info.round >= KNOCKOUT) LEAGUE_PHASE_ROUNDS else info.round
        if (last <= 0) return emptyList()
        val all = ArrayList<Match>()
        for (r in 1..last) {
            progress(r, last)
            all.addAll(round(league, r, info.season, force && r >= last - 1))
        }
        return computeTable(all)
    }

    private const val LEAGUE_PHASE_ROUNDS = 8

    private class Acc(val id: String?, val name: String, var badge: String?) {
        var played = 0
        var win = 0
        var draw = 0
        var loss = 0
        var gf = 0
        var ga = 0
        val form = StringBuilder()
        val points get() = win * 3 + draw
        val gd get() = gf - ga
    }

    private fun computeTable(list: List<Match>): List<Standing> {
        val table = LinkedHashMap<String, Acc>()
        fun acc(id: String?, name: String, badge: String?): Acc =
            table.getOrPut(id ?: name) { Acc(id, name, badge) }.also { if (it.badge == null) it.badge = badge }

        list.distinctBy { it.id }
            .filter { it.hasScore && !it.isLive }
            .sortedBy { it.sortKey }
            .forEach { m ->
                val hs = m.homeScore?.toIntOrNull() ?: return@forEach
                val aws = m.awayScore?.toIntOrNull() ?: return@forEach
                val home = acc(m.homeId, m.home, m.homeBadge ?: badges[m.homeId ?: ""])
                val away = acc(m.awayId, m.away, m.awayBadge ?: badges[m.awayId ?: ""])
                home.played++
                away.played++
                home.gf += hs
                home.ga += aws
                away.gf += aws
                away.ga += hs
                when {
                    hs > aws -> { home.win++; away.loss++; home.form.append('W'); away.form.append('L') }
                    hs < aws -> { away.win++; home.loss++; away.form.append('W'); home.form.append('L') }
                    else -> { home.draw++; away.draw++; home.form.append('D'); away.form.append('D') }
                }
            }
        val sorted = table.values.sortedWith(
            compareByDescending<Acc> { it.points }
                .thenByDescending { it.gd }
                .thenByDescending { it.gf }
                .thenBy { it.name.lowercase() },
        )
        return sorted.mapIndexed { i, a ->
            Standing(
                rank = (i + 1).toString(),
                teamId = a.id,
                team = a.name,
                badge = a.badge,
                played = a.played.toString(),
                win = a.win.toString(),
                draw = a.draw.toString(),
                loss = a.loss.toString(),
                goalDiff = if (a.gd > 0) "+${a.gd}" else a.gd.toString(),
                points = a.points.toString(),
                form = a.form.takeLast(5).toString(),
                note = null,
            )
        }
    }

    // ------------------------------------------------------------------ teams & players

    suspend fun teamNext(teamId: String, force: Boolean): List<Match> =
        events("eventsnext.php?id=$teamId", HALF_HOUR, force).filter { !it.isFinished }.sortedBy { it.sortKey }

    suspend fun teamLast(teamId: String, force: Boolean): List<Match> =
        events("eventslast.php?id=$teamId", HALF_HOUR, force).filter { it.hasScore }.sortedByDescending { it.sortKey }

    suspend fun favouriteMatches(teams: List<Team>, results: Boolean, force: Boolean): List<Match> {
        val all = ArrayList<Match>()
        for (t in teams) {
            all.addAll(if (results) teamLast(t.id, force) else teamNext(t.id, force))
        }
        val distinct = all.distinctBy { it.id }
        return if (results) distinct.sortedByDescending { it.sortKey } else distinct.sortedBy { it.sortKey }
    }

    suspend fun event(id: String, force: Boolean): Match? {
        if (!force) knownMatch(id)?.let { return it }
        return events("lookupevent.php?id=$id", SHORT, force).firstOrNull() ?: knownMatch(id)
    }

    suspend fun team(id: String, force: Boolean): Team? =
        fetch("lookupteam.php?id=$id", DAY, force, "teams").firstOrNull()?.let { Team.from(it) }
            ?.also { t -> t.badge?.let { badges[t.id] = it } }

    suspend fun searchTeams(query: String, force: Boolean): List<Team> =
        fetch("searchteams.php?t=${enc(query)}", DAY, force, "teams")
            .mapNotNull { Team.from(it) }
            .filter { it.sport == null || it.sport.equals("Soccer", ignoreCase = true) }

    suspend fun players(team: Team, force: Boolean): List<Player> =
        fetch("lookup_all_players.php?id=${team.id}", DAY, force, "player", "players")
            .mapNotNull { Player.from(it) }
            .filter { it.teamId == null || it.teamId == team.id }
            .distinctBy { it.id }

    suspend fun player(id: String, force: Boolean): Player? =
        fetch("lookupplayer.php?id=$id", DAY, force, "players", "player").firstOrNull()?.let { Player.from(it) }

    suspend fun searchPlayers(query: String, force: Boolean): List<Player> =
        fetch("searchplayers.php?p=${enc(query)}", DAY, force, "player", "players")
            .mapNotNull { Player.from(it) }
            .filter { it.sport == null || it.sport.equals("Soccer", ignoreCase = true) }
}
