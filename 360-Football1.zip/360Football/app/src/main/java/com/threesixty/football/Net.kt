package com.threesixty.football

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

class HttpException(val code: Int) : IOException("HTTP $code")

/**
 * TheSportsDB's free plan allows about 10 requests a minute and blocks for a while after that.
 * Every request waits its turn here so the app stays under the limit instead of getting blocked.
 */
object RateLimiter {
    private const val PER_MINUTE = 9
    private const val WINDOW = 60_000L
    private val mutex = Mutex()
    private val stamps = ArrayDeque<Long>()
    @Volatile private var blockedUntil = 0L

    suspend fun acquire() {
        mutex.withLock {
            while (true) {
                val now = System.currentTimeMillis()
                if (now < blockedUntil) {
                    delay(blockedUntil - now)
                    continue
                }
                while (stamps.isNotEmpty() && now - stamps.first() >= WINDOW) stamps.removeFirst()
                if (stamps.size < PER_MINUTE) {
                    stamps.addLast(now)
                    return
                }
                delay(WINDOW - (now - stamps.first()) + 100)
            }
        }
    }

    /** The server said "too many requests": back off before trying again. */
    fun blocked(ms: Long) {
        blockedUntil = maxOf(blockedUntil, System.currentTimeMillis() + ms)
    }

    fun isBlocked(): Boolean = System.currentTimeMillis() < blockedUntil
}

/** Tiny HTTP client with a disk cache, so the app is fast and still works offline. */
object Net {
    private lateinit var dir: File

    fun init(ctx: Context) {
        dir = File(ctx.cacheDir, "api").apply { mkdirs() }
    }

    private fun file(url: String) = File(dir, hash(url))

    /** Last saved copy of [url], however old, or null. */
    fun peek(url: String): String? {
        val f = file(url)
        return if (f.exists()) f.readText() else null
    }

    suspend fun get(url: String, ttlMs: Long, force: Boolean): String {
        val f = file(url)
        if (!force && f.exists() && System.currentTimeMillis() - f.lastModified() < ttlMs) {
            return f.readText()
        }
        var attempt = 0
        while (true) {
            // If we're blocked and have an older copy, show that instead of waiting.
            if (RateLimiter.isBlocked() && f.exists()) return f.readText()
            RateLimiter.acquire()
            try {
                val body = withContext(Dispatchers.IO) { String(download(url), Charsets.UTF_8) }
                f.writeText(body)
                return body
            } catch (e: HttpException) {
                if (e.code == 429) {
                    RateLimiter.blocked(60_000)
                    if (f.exists()) return f.readText()
                    if (attempt++ < 2) continue
                }
                if (f.exists()) return f.readText()
                throw e
            } catch (e: IOException) {
                if (f.exists()) return f.readText()
                throw e
            }
        }
    }

    fun download(url: String): ByteArray {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 20_000
        conn.setRequestProperty("User-Agent", "360-Football/1.1 (Android)")
        try {
            val code = conn.responseCode
            if (code != HttpURLConnection.HTTP_OK) throw HttpException(code)
            return conn.inputStream.use { it.readBytes() }
        } finally {
            conn.disconnect()
        }
    }

    fun clear() {
        dir.listFiles()?.forEach { it.delete() }
    }

    fun hash(s: String): String =
        MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
}
