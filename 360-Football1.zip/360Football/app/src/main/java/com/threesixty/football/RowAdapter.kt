package com.threesixty.football

import android.annotation.SuppressLint
import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.color.MaterialColors

/** Everything the app shows is a list of these rows. */
sealed class Row {
    data class Header(val title: String, val sub: String? = null) : Row()
    data class MatchItem(val m: Match, val showDate: Boolean = false, val showLeague: Boolean = false) : Row()
    data class TeamItem(val t: Team) : Row()
    data class PlayerItem(val p: Player) : Row()
    object TableHead : Row()
    data class TableItem(val s: Standing) : Row()
    data class Fact(val label: String, val value: String, val onClick: (() -> Unit)? = null) : Row()
    data class Text(val text: String) : Row()
    data class Hero(val title: String, val sub: String?, val image: String?, val banner: String?, val placeholder: Int) : Row()
    data class Score(val m: Match) : Row()
    data class Action(val label: String, val onClick: () -> Unit) : Row()
}

class RowAdapter(private val activity: Activity) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        const val SPAN = 3
    }

    private var rows: List<Row> = emptyList()

    @SuppressLint("NotifyDataSetChanged")
    fun submit(newRows: List<Row>) {
        rows = newRows
        notifyDataSetChanged()
    }

    /** Teams show as a 3-column grid; everything else spans the full width. */
    fun layoutManager(): GridLayoutManager {
        val lm = GridLayoutManager(activity, SPAN)
        lm.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int = if (rows.getOrNull(position) is Row.TeamItem) 1 else SPAN
        }
        return lm
    }

    override fun getItemCount(): Int = rows.size

    override fun getItemViewType(position: Int): Int = when (rows[position]) {
        is Row.Header -> R.layout.item_header
        is Row.MatchItem -> R.layout.item_match
        is Row.TeamItem -> R.layout.item_team
        is Row.PlayerItem -> R.layout.item_player
        Row.TableHead -> R.layout.item_table_head
        is Row.TableItem -> R.layout.item_table
        is Row.Fact -> R.layout.item_fact
        is Row.Text -> R.layout.item_text
        is Row.Hero -> R.layout.item_hero
        is Row.Score -> R.layout.item_score
        is Row.Action -> R.layout.item_button
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(viewType, parent, false)
        return object : RecyclerView.ViewHolder(view) {}
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val v = holder.itemView
        when (val row = rows[position]) {
            is Row.Header -> bindHeader(v, row)
            is Row.MatchItem -> bindMatch(v, row)
            is Row.TeamItem -> bindTeam(v, row.t)
            is Row.PlayerItem -> bindPlayer(v, row.p)
            Row.TableHead -> Unit
            is Row.TableItem -> bindTable(v, row.s)
            is Row.Fact -> bindFact(v, row)
            is Row.Text -> bindText(v, row)
            is Row.Hero -> bindHero(v, row)
            is Row.Score -> bindScore(v, row.m)
            is Row.Action -> {
                val b = v.findViewById<MaterialButton>(R.id.action_button)
                b.text = row.label
                b.setOnClickListener { row.onClick() }
            }
        }
    }

    // ------------------------------------------------------------------ binders

    private fun bindHeader(v: View, r: Row.Header) {
        v.findViewById<TextView>(R.id.header_title).text = r.title
        val sub = v.findViewById<TextView>(R.id.header_sub)
        sub.text = r.sub
        sub.visibility = if (r.sub.isNullOrBlank()) View.GONE else View.VISIBLE
    }

    private fun bindMatch(v: View, r: Row.MatchItem) {
        val m = r.m
        val meta = ArrayList<String>()
        if (r.showLeague) m.league?.let { meta.add(it) }
        if (r.showDate) Format.localDate(m)?.let { meta.add(Format.shortDay(it)) }
        m.round?.takeIf { it != "0" }?.let { meta.add(activity.getString(R.string.round_n, it)) }
        m.venue?.let { meta.add(it) }
        val metaView = v.findViewById<TextView>(R.id.match_meta)
        metaView.text = meta.joinToString(" · ")
        metaView.visibility = if (meta.isEmpty()) View.GONE else View.VISIBLE

        v.findViewById<TextView>(R.id.home_name).text = m.home
        v.findViewById<TextView>(R.id.away_name).text = m.away
        Images.load(v.findViewById(R.id.home_badge), m.homeBadge ?: Api.badge(m.homeId), R.drawable.ic_shield_placeholder)
        Images.load(v.findViewById(R.id.away_badge), m.awayBadge ?: Api.badge(m.awayId), R.drawable.ic_shield_placeholder)

        val center = v.findViewById<TextView>(R.id.match_center)
        val status = v.findViewById<TextView>(R.id.match_status)
        applyScore(center, status, m, v)
        v.setOnClickListener { DetailActivity.openMatch(activity, m.id, "${m.home} v ${m.away}") }
    }

    /** Fills the score/kick-off text and the small status line under it. */
    private fun applyScore(center: TextView, status: TextView, m: Match, v: View) {
        val muted = MaterialColors.getColor(v, com.google.android.material.R.attr.colorOnSurfaceVariant)
        status.setTextColor(muted)
        val kickoff = m.kickoff
        when {
            m.hasScore -> {
                center.text = activity.getString(R.string.score, m.homeScore, m.awayScore)
                when {
                    m.isLive -> {
                        status.text = activity.getString(R.string.live_status, m.status ?: "")
                        status.setTextColor(ContextCompat.getColor(activity, R.color.live))
                    }
                    m.isFinished -> status.text = activity.getString(R.string.full_time)
                    else -> status.text = m.status ?: ""
                }
            }
            m.isPostponed -> {
                center.text = activity.getString(R.string.dash)
                status.text = activity.getString(R.string.postponed)
            }
            kickoff != null -> {
                center.text = Format.time(activity, kickoff)
                status.text = ""
            }
            else -> {
                center.text = activity.getString(R.string.tbc)
                status.text = ""
            }
        }
        status.visibility = if (status.text.isNullOrEmpty()) View.GONE else View.VISIBLE
    }

    private fun bindTeam(v: View, t: Team) {
        v.findViewById<TextView>(R.id.team_name).text = t.name
        Images.load(v.findViewById(R.id.team_badge), t.badge, R.drawable.ic_shield_placeholder)
        v.setOnClickListener { DetailActivity.openTeam(activity, t.id, t.name) }
    }

    private fun bindPlayer(v: View, p: Player) {
        v.findViewById<TextView>(R.id.player_name).text = p.name
        val sub = listOfNotNull(p.position, p.nationality).joinToString(" · ")
        val subView = v.findViewById<TextView>(R.id.player_sub)
        subView.text = sub
        subView.visibility = if (sub.isEmpty()) View.GONE else View.VISIBLE
        val number = v.findViewById<TextView>(R.id.player_number)
        number.text = p.number ?: ""
        Images.load(v.findViewById(R.id.player_photo), p.photo, R.drawable.ic_person)
        v.setOnClickListener { DetailActivity.openPlayer(activity, p.id, p.name) }
    }

    private fun bindTable(v: View, s: Standing) {
        val rank = v.findViewById<TextView>(R.id.t_rank)
        rank.text = s.rank
        val note = s.note?.lowercase() ?: ""
        val colorRes = when {
            note.contains("relegation") -> R.color.q_relegation
            note.contains("champions") -> R.color.q_champions
            note.contains("europa") -> R.color.q_europa
            note.contains("conference") -> R.color.q_conference
            note.contains("promotion") || note.contains("play") -> R.color.q_conference
            else -> 0
        }
        if (colorRes != 0) {
            rank.setTextColor(ContextCompat.getColor(activity, colorRes))
        } else {
            rank.setTextColor(MaterialColors.getColor(v, com.google.android.material.R.attr.colorOnSurface))
        }
        Images.load(v.findViewById(R.id.t_badge), s.badge ?: Api.badge(s.teamId), R.drawable.ic_shield_placeholder)
        v.findViewById<TextView>(R.id.t_team).text = s.team
        v.findViewById<TextView>(R.id.t_played).text = s.played
        v.findViewById<TextView>(R.id.t_win).text = s.win
        v.findViewById<TextView>(R.id.t_draw).text = s.draw
        v.findViewById<TextView>(R.id.t_loss).text = s.loss
        v.findViewById<TextView>(R.id.t_gd).text = s.goalDiff
        v.findViewById<TextView>(R.id.t_points).text = s.points
        val id = s.teamId
        if (id != null) {
            v.setOnClickListener { DetailActivity.openTeam(activity, id, s.team) }
        } else {
            v.setOnClickListener(null)
        }
    }

    private fun bindFact(v: View, r: Row.Fact) {
        v.findViewById<TextView>(R.id.fact_label).text = r.label
        val value = v.findViewById<TextView>(R.id.fact_value)
        value.text = r.value
        val click = r.onClick
        if (click != null) {
            value.setTextColor(MaterialColors.getColor(v, androidx.appcompat.R.attr.colorPrimary))
            v.setOnClickListener { click() }
        } else {
            value.setTextColor(MaterialColors.getColor(v, com.google.android.material.R.attr.colorOnSurface))
            v.setOnClickListener(null)
            v.isClickable = false
        }
    }

    private fun bindText(v: View, r: Row.Text) {
        val tv = v.findViewById<TextView>(R.id.text_body)
        tv.text = r.text
        tv.maxLines = 6
        tv.setOnClickListener { tv.maxLines = if (tv.maxLines == 6) Int.MAX_VALUE else 6 }
    }

    private fun bindHero(v: View, r: Row.Hero) {
        val banner = v.findViewById<ImageView>(R.id.hero_banner)
        if (r.banner != null) {
            banner.visibility = View.VISIBLE
            Images.load(banner, r.banner, 0)
        } else {
            banner.visibility = View.GONE
        }
        Images.load(v.findViewById(R.id.hero_image), r.image, r.placeholder)
        v.findViewById<TextView>(R.id.hero_title).text = r.title
        val sub = v.findViewById<TextView>(R.id.hero_sub)
        sub.text = r.sub
        sub.visibility = if (r.sub.isNullOrBlank()) View.GONE else View.VISIBLE
    }

    private fun bindScore(v: View, m: Match) {
        v.findViewById<TextView>(R.id.sc_home_name).text = m.home
        v.findViewById<TextView>(R.id.sc_away_name).text = m.away
        val homeBadge = v.findViewById<ImageView>(R.id.sc_home_badge)
        val awayBadge = v.findViewById<ImageView>(R.id.sc_away_badge)
        Images.load(homeBadge, m.homeBadge ?: Api.badge(m.homeId), R.drawable.ic_shield_placeholder)
        Images.load(awayBadge, m.awayBadge ?: Api.badge(m.awayId), R.drawable.ic_shield_placeholder)
        val homeId = m.homeId
        val awayId = m.awayId
        if (homeId != null) homeBadge.setOnClickListener { DetailActivity.openTeam(activity, homeId, m.home) }
        if (awayId != null) awayBadge.setOnClickListener { DetailActivity.openTeam(activity, awayId, m.away) }
        applyScore(v.findViewById(R.id.sc_score), v.findViewById(R.id.sc_status), m, v)
        val date = v.findViewById<TextView>(R.id.sc_date)
        val text = Format.kickoff(activity, m)
        date.text = text
        date.visibility = if (text == null) View.GONE else View.VISIBLE
    }
}
