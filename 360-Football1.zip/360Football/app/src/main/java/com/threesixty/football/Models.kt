package com.threesixty.football

import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneOffset

/** First non-blank string among [keys], or null. */
fun JSONObject.str(vararg keys: String): String? {
    for (k in keys) {
        if (!has(k) || isNull(k)) continue
        val v = opt(k)?.toString()?.trim() ?: continue
        if (v.isNotEmpty() && v != "null") return v
    }
    return null
}

data class League(
    val id: String,
    val name: String,
    val apiName: String,
    val calendarYear: Boolean = false,
) {
    fun season(): String {
        val now = LocalDate.now()
        val y = now.year
        return when {
            calendarYear -> "$y"
            now.monthValue >= 7 -> "$y-${y + 1}"
            else -> "${y - 1}-$y"
        }
    }
}

object Leagues {
    const val FAVOURITES = "fav"

    val all = listOf(
        League("4335", "La Liga", "Spanish La Liga"),
        League("4328", "Premier League", "English Premier League"),
        League("4668", "Saudi Pro League", "Saudi-Arabian Pro League"),
        League("4480", "Champions League", "UEFA Champions League"),
        League("4332", "Serie A", "Italian Serie A"),
        League("4331", "Bundesliga", "German Bundesliga"),
        League("4334", "Ligue 1", "French Ligue 1"),
        League("4481", "Europa League", "UEFA Europa League"),
        League("4337", "Eredivisie", "Dutch Eredivisie"),
        League("4344", "Primeira Liga", "Portuguese Primeira Liga"),
        League("4346", "MLS", "American Major League Soccer", calendarYear = true),
    )

    fun byId(id: String): League? = all.firstOrNull { it.id == id }
}

data class Match(
    val id: String,
    val league: String?,
    val leagueId: String?,
    val home: String,
    val away: String,
    val homeId: String?,
    val awayId: String?,
    val homeScore: String?,
    val awayScore: String?,
    val homeBadge: String?,
    val awayBadge: String?,
    val kickoff: Instant?,
    val date: LocalDate?,
    val venue: String?,
    val round: String?,
    val status: String?,
    val season: String?,
    val video: String?,
    val description: String?,
    val referee: String?,
    val spectators: String?,
) {
    val hasScore: Boolean get() = homeScore != null && awayScore != null

    val isLive: Boolean get() = (status?.uppercase()?.trim() ?: "") in LIVE

    val isPostponed: Boolean
        get() = status?.lowercase()?.let { it.contains("postpon") || it.contains("cancel") || it.contains("abandon") } == true

    val isFinished: Boolean
        get() {
            val s = status?.lowercase()?.trim() ?: ""
            if (s in FINISHED) return true
            if (isLive) return false
            val old = kickoff?.isBefore(Instant.now().minusSeconds(3 * 3600L)) == true
            return hasScore && old
        }

    val sortKey: Long
        get() = kickoff?.epochSecond ?: date?.atStartOfDay()?.toEpochSecond(ZoneOffset.UTC) ?: Long.MAX_VALUE

    companion object {
        private val FINISHED = setOf("match finished", "ft", "aet", "pen", "after extra time", "after penalties", "full time", "finished")
        private val LIVE = setOf("1H", "2H", "HT", "ET", "BT", "P", "LIVE", "IN PLAY", "INPLAY", "HALFTIME")

        fun from(o: JSONObject): Match? {
            val id = o.str("idEvent") ?: return null
            val home = o.str("strHomeTeam") ?: return null
            val away = o.str("strAwayTeam") ?: return null
            val date = o.str("dateEvent")?.let { d ->
                try { LocalDate.parse(d.take(10)) } catch (e: Exception) { null }
            }
            return Match(
                id = id,
                league = o.str("strLeague"),
                leagueId = o.str("idLeague"),
                home = home,
                away = away,
                homeId = o.str("idHomeTeam"),
                awayId = o.str("idAwayTeam"),
                homeScore = o.str("intHomeScore"),
                awayScore = o.str("intAwayScore"),
                homeBadge = o.str("strHomeTeamBadge"),
                awayBadge = o.str("strAwayTeamBadge"),
                kickoff = parseKickoff(o.str("strTimestamp"), o.str("dateEvent"), o.str("strTime")),
                date = date,
                venue = o.str("strVenue"),
                round = o.str("intRound"),
                status = o.str("strStatus"),
                season = o.str("strSeason"),
                video = o.str("strVideo"),
                description = o.str("strDescriptionEN"),
                referee = o.str("strOfficial"),
                spectators = o.str("intSpectators"),
            )
        }

        /** TheSportsDB times are UTC. */
        fun parseKickoff(timestamp: String?, date: String?, time: String?): Instant? {
            if (timestamp != null && timestamp.length >= 16) {
                val t = timestamp.take(19).let { if (it.length == 16) "$it:00" else it }
                try {
                    return LocalDateTime.parse(t).toInstant(ZoneOffset.UTC)
                } catch (e: Exception) {
                    // fall through
                }
            }
            if (date != null && time != null && time.length >= 5 && !time.startsWith("00:00")) {
                try {
                    return LocalDateTime.parse(date.take(10) + "T" + time.take(5) + ":00").toInstant(ZoneOffset.UTC)
                } catch (e: Exception) {
                    // fall through
                }
            }
            return null
        }
    }
}

data class Standing(
    val rank: String,
    val teamId: String?,
    val team: String,
    val badge: String?,
    val played: String,
    val win: String,
    val draw: String,
    val loss: String,
    val goalDiff: String,
    val points: String,
    val form: String?,
    val note: String?,
) {
    companion object {
        fun from(o: JSONObject): Standing? {
            val team = o.str("strTeam", "name") ?: return null
            return Standing(
                rank = o.str("intRank") ?: "",
                teamId = o.str("idTeam", "teamid"),
                team = team,
                badge = o.str("strBadge", "strTeamBadge"),
                played = o.str("intPlayed", "played") ?: "0",
                win = o.str("intWin", "win") ?: "0",
                draw = o.str("intDraw", "draw") ?: "0",
                loss = o.str("intLoss", "loss") ?: "0",
                goalDiff = o.str("intGoalDifference", "goalsdifference") ?: "0",
                points = o.str("intPoints", "total") ?: "0",
                form = o.str("strForm"),
                note = o.str("strDescription"),
            )
        }
    }
}

data class Team(
    val id: String,
    val name: String,
    val badge: String? = null,
    val league: String? = null,
    val leagueIds: List<String> = emptyList(),
    val stadium: String? = null,
    val location: String? = null,
    val capacity: String? = null,
    val formed: String? = null,
    val country: String? = null,
    val website: String? = null,
    val banner: String? = null,
    val description: String? = null,
    val sport: String? = null,
    val shortName: String? = null,
) {
    companion object {
        fun from(o: JSONObject): Team? {
            val id = o.str("idTeam") ?: return null
            val name = o.str("strTeam") ?: return null
            val leagues = listOf("idLeague", "idLeague2", "idLeague3", "idLeague4", "idLeague5", "idLeague6", "idLeague7")
                .mapNotNull { o.str(it) }
            return Team(
                id = id,
                name = name,
                badge = o.str("strBadge", "strTeamBadge"),
                league = o.str("strLeague"),
                leagueIds = leagues,
                stadium = o.str("strStadium", "strVenue"),
                location = o.str("strLocation", "strStadiumLocation"),
                capacity = o.str("intStadiumCapacity"),
                formed = o.str("intFormedYear"),
                country = o.str("strCountry"),
                website = o.str("strWebsite"),
                banner = o.str("strFanart1", "strBanner", "strStadiumThumb", "strFanart2"),
                description = o.str("strDescriptionEN"),
                sport = o.str("strSport"),
                shortName = o.str("strTeamShort"),
            )
        }
    }
}

data class Player(
    val id: String,
    val name: String,
    val team: String?,
    val teamId: String?,
    val position: String?,
    val nationality: String?,
    val born: String?,
    val birthPlace: String?,
    val number: String?,
    val height: String?,
    val weight: String?,
    val photo: String?,
    val banner: String?,
    val description: String?,
    val foot: String?,
    val sport: String?,
) {
    companion object {
        fun from(o: JSONObject): Player? {
            val id = o.str("idPlayer") ?: return null
            val name = o.str("strPlayer") ?: return null
            return Player(
                id = id,
                name = name,
                team = o.str("strTeam"),
                teamId = o.str("idTeam"),
                position = o.str("strPosition"),
                nationality = o.str("strNationality"),
                born = o.str("dateBorn"),
                birthPlace = o.str("strBirthLocation"),
                number = o.str("strNumber"),
                height = o.str("strHeight"),
                weight = o.str("strWeight"),
                photo = o.str("strCutout", "strThumb", "strRender"),
                banner = o.str("strFanart1", "strBanner"),
                description = o.str("strDescriptionEN"),
                foot = o.str("strSide"),
                sport = o.str("strSport"),
            )
        }
    }
}
