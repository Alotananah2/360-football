package com.threesixty.football

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.View
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.io.IOException
import java.net.UnknownHostException

object Ui {
    /** Pads the root view so content sits between the status bar and the navigation bar. */
    fun applyInsets(root: View) {
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            WindowInsetsCompat.CONSUMED
        }
    }

    fun errorText(ctx: Context, e: Throwable): String = when {
        e is HttpException && e.code == 429 -> ctx.getString(R.string.err_rate_limit)
        e is HttpException -> ctx.getString(R.string.err_server, e.code)
        e is UnknownHostException -> ctx.getString(R.string.err_offline)
        e is IOException -> ctx.getString(R.string.err_offline)
        else -> ctx.getString(R.string.err_generic, e.message ?: e.javaClass.simpleName)
    }

    fun openUrl(ctx: Context, url: String) {
        val full = if (url.startsWith("http")) url else "https://$url"
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(full)))
        } catch (e: Exception) {
            Toast.makeText(ctx, R.string.no_browser, Toast.LENGTH_SHORT).show()
        }
    }

    /** Groups matches under date headers ("Today", "Tomorrow", "Saturday 8 November"). */
    fun matchRows(ctx: Context, matches: List<Match>, showLeague: Boolean): List<Row> {
        val rows = ArrayList<Row>()
        var first = true
        var last: java.time.LocalDate? = null
        for (m in matches) {
            val d = Format.localDate(m)
            if (first || d != last) {
                rows.add(Row.Header(Format.dayHeader(ctx, d)))
                last = d
                first = false
            }
            rows.add(Row.MatchItem(m, showDate = false, showLeague = showLeague))
        }
        return rows
    }
}
