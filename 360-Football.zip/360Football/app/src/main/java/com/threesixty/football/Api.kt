package com.threesixty.football

import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.TreeSet
import java.util.concurrent.ConcurrentHashMap

/** ESPN's public football data: free, no key, and fast. */
object Api {
    private const val SITE = "https://site.api.espn.com/apis/site/v2/sports/soccer/"
    private const val STANDINGS = "https://site.api.espn.com/apis/v2/sports/soccer/"
    private const val WEB = "https://site.web.api.espn.com/apis/"

    private const val MINUTE = 60_000L
    private const val HOUR = 60 * MINUTE
    private const val DAY = 24 * HOUR

    private val ymd = DateTimeFormatter.ofPattern("yyyyMMdd")
    private val badges = ConcurrentHashMap<String, String>()
    private val players = ConcurrentHashMap<String, Player>()

    fun badge(teamId: String?): String? = teamId?.let { badges[it] }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private suspend fun json(url: String, ttl: Long, force: Boolean): JSONObject {
        val body = Net.get(url, ttl, force)
        return try {
            JSONObject(body)
        } catch (e: JSONException) {
            throw IOException("Unexpected data from server")
        }
    }

    private fun remember(list: List<Match>): List<Match> {
        list.forEach { m ->
            val hid = m.homeId
            val aid = m.awayId
            val hb = m.homeBadge
            val ab = m.awayBadge
            if (hid != null && hb != null) badges[hid] = hb
            if (aid != null && ab != null) badges[aid] = ab
        }
        return list
    }

    // ------------------------------------------------------------------ fixtures & results

    /**
     * Days with matches. Leagues publish every match day; cups (Champions League etc.) only
     * publish long phases, so for those we return null and scan day by day instead.
     */
    private suspend fun matchDays(league: League, force: Boolean): List<LocalDate>? {
        val root = json(SITE + "${league.id}/scoreboard", HOUR, force)
        val lg = root.list("leagues").firstOrNull() ?: return null
        val cal = lg.optJSONArray("calendar") ?: return null
        val days = TreeSet<LocalDate>()
        for (i in 0 until cal.length()) {
            val item = cal.opt(i)
            if (item is String) parseDay(item)?.let { days.add(it) }
        }
        return if (days.isEmpty()) null else days.toList()
    }

    private fun range(from: LocalDate, to: LocalDate): List<LocalDate> {
        val out = ArrayList<LocalDate>()
        var d = from
        while (!d.isAfter(to)) {
            out.add(d)
            d = d.plusDays(1)
        }
        return out
    }

    private suspend fun scoreboard(league: League, day: LocalDate, force: Boolean): List<Match> {
        val today = LocalDate.now()
        val ttl = when {
            day.isBefore(today.minusDays(1)) -> DAY
            day.isAfter(today.plusDays(1)) -> 30 * MINUTE
            else -> MINUTE
        }
        val root = json(SITE + "${league.id}/scoreboard?dates=${ymd.format(day)}", ttl, force)
        return remember(root.list("events").mapNotNull { Match.from(it, league.name) })
    }

    private val gate = Semaphore(8)

    private suspend fun days(league: League, days: List<LocalDate>, force: Boolean): List<Match> = coroutineScope {
        days.map { d -> async { gate.withPermit { runCatching { scoreboard(league, d, force) } } } }.awaitAll().let { results ->
            if (results.isNotEmpty() && results.all { it.isFailure }) {
                throw results.first().exceptionOrNull() ?: IOException("No data")
            }
            results.flatMap { it.getOrDefault(emptyList()) }
        }
    }

    suspend fun upcoming(league: League, force: Boolean): List<Match> {
        val today = LocalDate.now()
        val from = today.minusDays(1)
        val picked = matchDays(league, force)?.filter { !it.isBefore(from) }?.take(6)
            ?: range(from, today.plusDays(28))
        return days(league, picked, force)
            .distinctBy { it.id }
            .filter { !it.isFinished && !it.isPostponed }
            .sortedBy { it.sortKey }
    }

    suspend fun results(league: League, force: Boolean): List<Match> {
        val today = LocalDate.now()
        val to = today.plusDays(1)
        val picked = matchDays(league, force)?.filter { !it.isAfter(to) }?.takeLast(6)
            ?: range(today.minusDays(21), to)
        return days(league, picked, force)
            .distinctBy { it.id }
            .filter { it.hasScore }
            .sortedByDescending { it.sortKey }
    }

    // ------------------------------------------------------------------ tables & teams

    suspend fun table(league: League, force: Boolean): List<TableGroup> {
        val root = json(STANDINGS + "${league.id}/standings", 10 * MINUTE, force)
        val groups = root.list("children").ifEmpty { listOf(root) }
        return groups.mapNotNull { g ->
            val entries = g.obj("standings")?.list("entries") ?: return@mapNotNull null
            val rows = entries.mapIndexedNotNull { i, e -> Standing.from(e, i) }
                .sortedBy { it.rank.toIntOrNull() ?: 999 }
            rows.forEach { s ->
                val id = s.teamId
                val b = s.badge
                if (id != null && b != null) badges[id] = b
            }
            if (rows.isEmpty()) null else TableGroup(if (groups.size > 1) g.str("name") else null, rows)
        }
    }

    suspend fun teams(league: League, force: Boolean): List<Team> {
        val root = json(SITE + "${league.id}/teams", DAY, force)
        val list = root.list("sports").firstOrNull()?.list("leagues")?.firstOrNull()?.list("teams") ?: emptyList()
        return list.mapNotNull { it.obj("team") }.mapNotNull { t ->
            val id = t.str("id") ?: return@mapNotNull null
            val badge = t.logo()
            if (badge != null) badges[id] = badge
            Team(id, t.str("displayName", "name") ?: return@mapNotNull null, badge, league.id)
        }.sortedBy { it.name.lowercase() }
    }

    suspend fun team(id: String, force: Boolean): Team? {
        val t = json(SITE + "all/teams/$id", HOUR, force).obj("team") ?: return null
        val badge = t.logo()
        if (badge != null) badges[id] = badge
        return Team(
            id = id,
            name = t.str("displayName", "name") ?: return null,
            badge = badge,
            leagueSlug = t.obj("defaultLeague")?.str("slug", "midsizeName"),
            location = t.str("location"),
            venue = t.obj("franchise")?.obj("venue")?.str("fullName") ?: t.obj("venue")?.str("fullName"),
            record = t.obj("record")?.list("items")?.firstOrNull()?.str("summary"),
            standing = t.str("standingSummary"),
        )
    }

    suspend fun squad(team: Team, force: Boolean): List<Player> {
        val slug = team.leagueSlug ?: return emptyList()
        val root = json(SITE + "$slug/teams/${team.id}/roster", DAY, force)
        // Some rosters come grouped by position: flatten them.
        val raw = root.list("athletes").flatMap { a -> if (a.has("items")) a.list("items") else listOf(a) }
        return raw.mapNotNull { Player.fromRoster(it, team) }.onEach { players[it.id] = it }
    }

    suspend fun teamFixtures(id: String, force: Boolean): List<Match> {
        val root = json(SITE + "all/teams/$id/schedule?fixture=true", 30 * MINUTE, force)
        return remember(root.list("events").mapNotNull { Match.from(it, null) })
            .filter { !it.isFinished }
            .sortedBy { it.sortKey }
    }

    suspend fun teamResults(id: String, force: Boolean): List<Match> {
        val root = json(SITE + "all/teams/$id/schedule", 30 * MINUTE, force)
        return remember(root.list("events").mapNotNull { Match.from(it, null) })
            .filter { it.hasScore }
            .sortedByDescending { it.sortKey }
    }

    suspend fun favouriteMatches(teams: List<Team>, results: Boolean, force: Boolean): List<Match> = coroutineScope {
        val lists = teams.map { t ->
            async { runCatching { if (results) teamResults(t.id, force).take(5) else teamFixtures(t.id, force).take(5) } }
        }.awaitAll()
        if (lists.isNotEmpty() && lists.all { it.isFailure }) throw lists.first().exceptionOrNull() ?: IOException("No data")
        val all = lists.flatMap { it.getOrDefault(emptyList()) }.distinctBy { it.id }
        if (results) all.sortedByDescending { it.sortKey } else all.sortedBy { it.sortKey }
    }

    // ------------------------------------------------------------------ match details

    data class Event(val minute: String, val kind: String, val text: String, val home: Boolean)
    data class Lineup(val teamId: String?, val team: String, val formation: String?, val players: List<Player>)
    data class MatchDetail(
        val match: Match,
        val events: List<Event>,
        val lineups: List<Lineup>,
        val venue: String?,
        val attendance: String?,
        val referee: String?,
    )

    suspend fun match(id: String, force: Boolean): MatchDetail? {
        val root = json(SITE + "all/summary?event=$id", MINUTE, force)
        val header = root.obj("header") ?: return null
        val comp = header.list("competitions").firstOrNull() ?: return null
        val leagueName = header.obj("league")?.str("name", "abbreviation")
        val m = Match.from(header, leagueName, comp) ?: return null
        remember(listOf(m))

        val events = root.list("keyEvents").mapNotNull { k ->
            val kind = k.obj("type")?.str("text") ?: return@mapNotNull null
            val lower = kind.lowercase()
            val wanted = k.optBoolean("scoringPlay") || lower.contains("goal") || lower.contains("card") || lower.contains("penalty")
            if (!wanted || lower.contains("kickoff") || lower.contains("halftime") || lower.contains("end")) return@mapNotNull null
            val who = k.list("participants").firstOrNull()?.obj("athlete")?.str("displayName")
            Event(
                minute = k.obj("clock")?.str("displayValue") ?: "",
                kind = kind,
                text = who ?: k.str("shortText") ?: kind,
                home = k.obj("team")?.str("id") == m.homeId,
            )
        }

        val lineups = root.list("rosters").mapNotNull { r ->
            val t = r.obj("team") ?: return@mapNotNull null
            val list = r.list("roster").mapNotNull { e ->
                val a = e.obj("athlete") ?: return@mapNotNull null
                val pid = a.str("id") ?: return@mapNotNull null
                Player(
                    id = pid,
                    name = a.str("displayName", "fullName") ?: return@mapNotNull null,
                    team = t.str("displayName"),
                    teamId = t.str("id"),
                    position = e.obj("position")?.str("displayName", "abbreviation"),
                    number = e.str("jersey"),
                    photo = a.obj("headshot")?.str("href") ?: Player.headshot(pid),
                    starter = e.optBoolean("starter"),
                )
            }
            if (list.isEmpty()) null else Lineup(t.str("id"), t.str("displayName") ?: "", r.str("formation"), list)
        }

        val info = root.obj("gameInfo")
        val venueObj = info?.obj("venue")
        val city = venueObj?.obj("address")?.str("city")
        val venue = venueObj?.str("fullName")?.let { if (city != null) "$it, $city" else it } ?: m.venue
        val referee = info?.list("officials")?.firstOrNull()?.str("displayName", "fullName")
        return MatchDetail(m, events, lineups, venue, info?.str("attendance")?.takeIf { it != "0" } ?: m.attendance, referee)
    }

    // ------------------------------------------------------------------ players & search

    suspend fun player(id: String, force: Boolean): Player? {
        val known = players[id]
        val a = try {
            json(WEB + "common/v3/sports/soccer/athletes/$id", DAY, force).obj("athlete")
        } catch (e: IOException) {
            if (known != null) return known else throw e
        } ?: return known
        val summary = a.obj("statsSummary")
        val stats = summary?.list("statistics")?.mapNotNull { s ->
            val label = s.str("displayName", "name") ?: return@mapNotNull null
            val value = s.str("displayValue") ?: return@mapNotNull null
            label to value
        } ?: emptyList()
        val team = a.obj("team")
        return Player(
            id = id,
            name = a.str("displayName", "fullName") ?: known?.name ?: return known,
            team = team?.str("displayName") ?: known?.team,
            teamId = team?.str("id") ?: known?.teamId,
            position = a.obj("position")?.str("displayName") ?: known?.position,
            nationality = a.str("citizenship") ?: known?.nationality,
            born = known?.born ?: a.str("displayDOB"),
            age = a.str("age") ?: known?.age,
            number = a.str("jersey") ?: known?.number,
            height = known?.height ?: a.str("displayHeight"),
            weight = known?.weight ?: a.str("displayWeight"),
            photo = a.obj("headshot")?.str("href") ?: known?.photo ?: Player.headshot(id),
            statsTitle = summary?.str("displayName"),
            stats = stats,
        )
    }

    data class SearchResult(val teams: List<Team>, val players: List<Player>)

    suspend fun search(query: String, force: Boolean): SearchResult {
        val root = json(WEB + "search/v2?query=${enc(query)}&limit=25", HOUR, force)
        val teams = ArrayList<Team>()
        val found = ArrayList<Player>()
        for (r in root.list("results")) {
            val type = r.str("type") ?: continue
            for (c in r.list("contents")) {
                if (c.str("sport") != "soccer") continue
                val uid = c.str("uid") ?: continue
                val name = c.str("displayName") ?: continue
                val image = c.obj("image")?.str("default")
                when (type) {
                    "team" -> {
                        val id = uid.substringAfter("~t:", "").takeIf { it.isNotEmpty() } ?: continue
                        teams.add(Team(id, name, image?.takeIf { it.contains("logo") } ?: badges[id], subtitle = c.str("subtitle")))
                    }
                    "player" -> {
                        val id = uid.substringAfter("~a:", "").takeIf { it.isNotEmpty() } ?: continue
                        found.add(Player(id, name, team = c.str("subtitle"), photo = image ?: Player.headshot(id)))
                    }
                }
            }
        }
        return SearchResult(teams.distinctBy { it.id }, found.distinctBy { it.id })
    }
}
