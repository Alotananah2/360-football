package com.threesixty.football

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.time.Instant
import java.time.LocalDate
import java.util.concurrent.ConcurrentHashMap

/** TheSportsDB v1 API (https://www.thesportsdb.com). All calls block; run them off the main thread. */
object Api {
    private const val BASE = "https://www.thesportsdb.com/api/v1/json/"
    private const val SHORT = 5 * 60_000L
    private const val HOUR = 60 * 60_000L
    private const val DAY = 24 * HOUR

    private val badges = ConcurrentHashMap<String, String>()

    /** Club badge we've already seen for this team id (events don't always include one). */
    fun badge(teamId: String?): String? = teamId?.let { badges[it] }

    private fun url(path: String) = BASE + Settings.apiKey + "/" + path
    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun fetch(path: String, ttl: Long, force: Boolean, vararg keys: String): List<JSONObject> {
        val body = Net.get(url(path), ttl, force)
        val root = try {
            JSONObject(body)
        } catch (e: JSONException) {
            return emptyList()
        }
        for (k in keys) {
            val arr = root.optJSONArray(k) ?: continue
            return (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
        }
        return emptyList()
    }

    private fun events(path: String, ttl: Long, force: Boolean): List<Match> =
        fetch(path, ttl, force, "events", "results", "event").mapNotNull { Match.from(it) }

    /** Runs calls in parallel. Fails only if every call failed. */
    private suspend fun <T> gather(calls: List<() -> List<T>>): List<T> = coroutineScope {
        val results = calls.map { call -> async(Dispatchers.IO) { runCatching { call() } } }.awaitAll()
        val ok = results.filter { it.isSuccess }
        if (ok.isEmpty() && results.isNotEmpty()) {
            throw results.first().exceptionOrNull() ?: IOException("No data")
        }
        ok.flatMap { it.getOrDefault(emptyList()) }
    }

    // ------------------------------------------------------------------ matches

    suspend fun upcoming(league: League, force: Boolean): List<Match> {
        val today = LocalDate.now()
        val calls = mutableListOf<() -> List<Match>>()
        calls.add { events("eventsnextleague.php?id=${league.id}", SHORT, force) }
        for (i in 0..7) {
            val day = today.plusDays(i.toLong())
            calls.add { events("eventsday.php?d=$day&l=${league.id}", SHORT, force) }
        }
        val cutoff = Instant.now().minusSeconds(3 * 3600L)
        return gather(calls)
            .filter { it.leagueId == null || it.leagueId == league.id }
            .distinctBy { it.id }
            .filter { m ->
                !m.isFinished && (m.kickoff?.isAfter(cutoff) ?: (m.date?.isBefore(today) != true))
            }
            .sortedBy { it.sortKey }
    }

    suspend fun results(league: League, force: Boolean): List<Match> {
        val today = LocalDate.now()
        val calls = mutableListOf<() -> List<Match>>()
        calls.add { events("eventspastleague.php?id=${league.id}", SHORT, force) }
        for (i in 0..7) {
            val day = today.minusDays(i.toLong())
            val ttl = if (i <= 1) SHORT else HOUR
            calls.add { events("eventsday.php?d=$day&l=${league.id}", ttl, force) }
        }
        return gather(calls)
            .filter { it.leagueId == null || it.leagueId == league.id }
            .distinctBy { it.id }
            .filter { it.hasScore }
            .sortedByDescending { it.sortKey }
    }

    fun teamNext(teamId: String, force: Boolean): List<Match> =
        events("eventsnext.php?id=$teamId", SHORT, force).filter { !it.isFinished }.sortedBy { it.sortKey }

    fun teamLast(teamId: String, force: Boolean): List<Match> =
        events("eventslast.php?id=$teamId", SHORT, force).filter { it.hasScore }.sortedByDescending { it.sortKey }

    suspend fun favouriteMatches(teams: List<Team>, results: Boolean, force: Boolean): List<Match> {
        if (teams.isEmpty()) return emptyList()
        val calls: List<() -> List<Match>> = teams.map { t ->
            { if (results) teamLast(t.id, force) else teamNext(t.id, force) }
        }
        val all = gather(calls).distinctBy { it.id }
        return if (results) all.sortedByDescending { it.sortKey } else all.sortedBy { it.sortKey }
    }

    fun event(id: String, force: Boolean): Match? =
        events("lookupevent.php?id=$id", SHORT, force).firstOrNull()

    // ------------------------------------------------------------------ tables & teams

    fun table(league: League, force: Boolean): List<Standing> {
        var rows = fetch("lookuptable.php?l=${league.id}&s=${league.season()}", HOUR, force, "table")
        if (rows.isEmpty()) rows = fetch("lookuptable.php?l=${league.id}", HOUR, force, "table")
        val table = rows.mapNotNull { Standing.from(it) }.sortedBy { it.rank.toIntOrNull() ?: 999 }
        table.forEach { s ->
            val id = s.teamId
            val b = s.badge
            if (id != null && b != null) badges.putIfAbsent(id, b)
        }
        return table
    }

    fun teams(league: League, force: Boolean): List<Team> {
        val found = LinkedHashMap<String, Team>()
        runCatching { fetch("search_all_teams.php?l=${enc(league.apiName)}", DAY, force, "teams") }
            .getOrDefault(emptyList())
            .mapNotNull { Team.from(it) }
            .forEach { found[it.id] = it }
        if (found.size < 10) {
            runCatching { fetch("lookup_all_teams.php?id=${league.id}", DAY, force, "teams") }
                .getOrDefault(emptyList())
                .mapNotNull { Team.from(it) }
                .filter { it.leagueIds.isEmpty() || league.id in it.leagueIds }
                .forEach { found.putIfAbsent(it.id, it) }
        }
        // Make sure every club in the table appears, even if the team search was limited.
        runCatching { table(league, force) }.getOrDefault(emptyList()).forEach { s ->
            val id = s.teamId
            if (id != null && !found.containsKey(id)) found[id] = Team(id, s.team, s.badge)
        }
        found.values.forEach { t -> t.badge?.let { badges[t.id] = it } }
        return found.values.sortedBy { it.name.lowercase() }
    }

    fun team(id: String, force: Boolean): Team? =
        fetch("lookupteam.php?id=$id", DAY, force, "teams").firstOrNull()?.let { Team.from(it) }
            ?.also { t -> t.badge?.let { badges[t.id] = it } }

    fun searchTeams(query: String, force: Boolean): List<Team> =
        fetch("searchteams.php?t=${enc(query)}", HOUR, force, "teams")
            .mapNotNull { Team.from(it) }
            .filter { it.sport == null || it.sport.equals("Soccer", ignoreCase = true) }

    // ------------------------------------------------------------------ players

    fun players(team: Team, force: Boolean): List<Player> {
        var rows = runCatching { fetch("lookup_all_players.php?id=${team.id}", DAY, force, "player", "players") }
            .getOrDefault(emptyList())
        if (rows.isEmpty()) {
            rows = runCatching { fetch("searchplayers.php?t=${enc(team.name)}", DAY, force, "player", "players") }
                .getOrDefault(emptyList())
        }
        return rows.mapNotNull { Player.from(it) }
            .filter { it.teamId == null || it.teamId == team.id }
            .distinctBy { it.id }
    }

    fun player(id: String, force: Boolean): Player? =
        fetch("lookupplayer.php?id=$id", DAY, force, "players", "player").firstOrNull()?.let { Player.from(it) }

    fun searchPlayers(query: String, force: Boolean): List<Player> =
        fetch("searchplayers.php?p=${enc(query)}", HOUR, force, "player", "players")
            .mapNotNull { Player.from(it) }
            .filter { it.sport == null || it.sport.equals("Soccer", ignoreCase = true) }
}
