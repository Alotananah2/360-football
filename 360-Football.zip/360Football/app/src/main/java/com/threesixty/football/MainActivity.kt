package com.threesixty.football

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    companion object {
        private val TABS = intArrayOf(R.id.nav_matches, R.id.nav_table, R.id.nav_teams)
        private const val TAB_MATCHES = 0
        private const val TAB_TABLE = 1
    }

    private lateinit var adapter: RowAdapter
    private lateinit var toolbar: MaterialToolbar
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var list: RecyclerView
    private lateinit var empty: TextView
    private lateinit var progress: ProgressBar
    private lateinit var toggle: MaterialButtonToggleGroup

    private var job: Job? = null
    private var leagueId = Leagues.all.first().id
    private var tab = 0
    private var showResults = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)
        Ui.applyInsets(findViewById(R.id.root))

        leagueId = Settings.league
        tab = Settings.tab.coerceIn(0, TABS.size - 1)
        showResults = Settings.showResults

        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        swipe = findViewById(R.id.swipe)
        list = findViewById(R.id.list)
        empty = findViewById(R.id.empty)
        progress = findViewById(R.id.progress)
        toggle = findViewById(R.id.match_toggle)

        adapter = RowAdapter(this)
        list.layoutManager = adapter.layoutManager()
        list.adapter = adapter

        swipe.setColorSchemeResources(R.color.pitch)
        swipe.setOnChildScrollUpCallback { _, _ -> list.canScrollVertically(-1) }
        swipe.setOnRefreshListener { load(force = true) }

        buildLeagueChips()

        toggle.check(if (showResults) R.id.btn_results else R.id.btn_upcoming)
        toggle.addOnButtonCheckedListener { _, id, checked ->
            if (checked) {
                showResults = id == R.id.btn_results
                Settings.showResults = showResults
                load()
            }
        }

        val nav = findViewById<BottomNavigationView>(R.id.bottom_nav)
        nav.selectedItemId = TABS[tab]
        nav.setOnItemSelectedListener { item ->
            val index = TABS.indexOf(item.itemId)
            if (index >= 0 && index != tab) {
                tab = index
                Settings.tab = tab
                load()
            }
            true
        }
        nav.setOnItemReselectedListener { list.smoothScrollToPosition(0) }

        load()
    }

    override fun onRestart() {
        super.onRestart()
        // Favourites may have changed on a team page.
        if (leagueId == Leagues.FAVOURITES) load()
    }

    private fun buildLeagueChips() {
        val group = findViewById<ChipGroup>(R.id.league_chips)
        val entries = listOf(Leagues.FAVOURITES to getString(R.string.my_teams)) + Leagues.all.map { it.id to it.name }
        var checkedChip: Chip? = null
        for ((id, name) in entries) {
            val chip = layoutInflater.inflate(R.layout.item_chip, group, false) as Chip
            chip.id = View.generateViewId()
            chip.text = name
            chip.tag = id
            group.addView(chip)
            if (id == leagueId) checkedChip = chip
        }
        val start = checkedChip ?: (group.getChildAt(1) as Chip)
        start.isChecked = true
        leagueId = start.tag as String
        group.setOnCheckedStateChangeListener { g, ids ->
            val chip = ids.firstOrNull()?.let { g.findViewById<Chip>(it) } ?: return@setOnCheckedStateChangeListener
            leagueId = chip.tag as String
            Settings.league = leagueId
            load()
        }
        val scroller = findViewById<HorizontalScrollView>(R.id.league_scroll)
        scroller.post { scroller.smoothScrollTo((start.left - 48).coerceAtLeast(0), 0) }
    }

    private fun load(force: Boolean = false) {
        job?.cancel()
        val league = Leagues.byId(leagueId)
        val currentTab = tab
        val results = showResults

        toggle.visibility = if (currentTab == TAB_MATCHES) View.VISIBLE else View.GONE
        toolbar.subtitle = league?.name ?: getString(R.string.my_teams)
        empty.visibility = View.GONE
        if (!force) {
            adapter.submit(emptyList())
            progress.visibility = View.VISIBLE
        }

        job = lifecycleScope.launch {
            try {
                val rows = buildRows(league, currentTab, results, force)
                adapter.submit(rows)
                if (rows.isEmpty()) showEmpty(emptyMessage(league, currentTab, results))
                list.scrollToPosition(0)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                adapter.submit(emptyList())
                showEmpty(Ui.errorText(this@MainActivity, e))
            } finally {
                progress.visibility = View.GONE
                swipe.isRefreshing = false
            }
        }
    }

    private suspend fun buildRows(league: League?, currentTab: Int, results: Boolean, force: Boolean): List<Row> {
        val ctx = this
        return when (currentTab) {
            TAB_MATCHES -> {
                if (league == null) {
                    val matches = Api.favouriteMatches(Favourites.all(), results, force)
                    Ui.matchRows(ctx, matches, showLeague = true)
                } else {
                    val matches = if (results) Api.results(league, force) else Api.upcoming(league, force)
                    Ui.matchRows(ctx, matches, showLeague = false)
                }
            }
            TAB_TABLE -> {
                if (league == null) {
                    emptyList()
                } else {
                    val table = io { Api.table(league, force) }
                    if (table.isEmpty()) {
                        emptyList()
                    } else {
                        listOf<Row>(Row.Header(getString(R.string.table_title, league.season()))) +
                            Row.TableHead + table.map { Row.TableItem(it) }
                    }
                }
            }
            else -> {
                val teams = if (league == null) Favourites.all() else io { Api.teams(league, force) }
                if (teams.isEmpty()) {
                    emptyList()
                } else {
                    listOf<Row>(Row.Header(getString(R.string.clubs_count, teams.size))) + teams.map { Row.TeamItem(it) }
                }
            }
        }
    }

    private fun emptyMessage(league: League?, currentTab: Int, results: Boolean): String = when {
        league == null && currentTab == TAB_TABLE -> getString(R.string.empty_fav_table)
        league == null && Favourites.all().isEmpty() -> getString(R.string.empty_favs)
        currentTab == TAB_MATCHES && results -> getString(R.string.empty_results)
        currentTab == TAB_MATCHES -> getString(R.string.empty_upcoming)
        else -> getString(R.string.empty_generic)
    }

    private fun showEmpty(text: String) {
        empty.text = text
        empty.visibility = View.VISIBLE
    }

    // ------------------------------------------------------------------ menu

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        R.id.action_search -> {
            showSearch()
            true
        }
        R.id.action_settings -> {
            showSettings()
            true
        }
        else -> super.onOptionsItemSelected(item)
    }

    private fun dialogBox(): LinearLayout {
        val pad = (20 * resources.displayMetrics.density).toInt()
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
        }
    }

    private fun showSearch() {
        val box = dialogBox()
        val input = EditText(this).apply {
            hint = getString(R.string.search_hint)
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEARCH
        }
        box.addView(input)
        var dialog: AlertDialog? = null
        val go = {
            val q = input.text.toString().trim()
            if (q.length >= 2) {
                dialog?.dismiss()
                DetailActivity.openSearch(this, q)
            } else {
                Toast.makeText(this, R.string.search_short, Toast.LENGTH_SHORT).show()
            }
        }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                go()
                true
            } else {
                false
            }
        }
        val d = MaterialAlertDialogBuilder(this)
            .setTitle(R.string.search_title)
            .setView(box)
            .setPositiveButton(R.string.search, null)
            .setNegativeButton(android.R.string.cancel, null)
            .create()
        dialog = d
        d.setOnShowListener {
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener { go() }
            input.requestFocus()
        }
        d.show()
    }

    private fun showSettings() {
        val box = dialogBox()
        val info = TextView(this).apply { text = getString(R.string.about_text) }
        val label = TextView(this).apply {
            text = getString(R.string.api_key_label)
            setPadding(0, (16 * resources.displayMetrics.density).toInt(), 0, 0)
        }
        val input = EditText(this).apply {
            isSingleLine = true
            setText(Settings.apiKey)
        }
        box.addView(info)
        box.addView(label)
        box.addView(input)
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.about_title)
            .setView(box)
            .setPositiveButton(R.string.save) { _, _ ->
                Settings.apiKey = input.text.toString()
                load(force = true)
            }
            .setNeutralButton(R.string.clear_cache) { _, _ ->
                Net.clear()
                Toast.makeText(this, R.string.cache_cleared, Toast.LENGTH_SHORT).show()
                load(force = true)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }
}
