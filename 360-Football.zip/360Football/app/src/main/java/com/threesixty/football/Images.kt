package com.threesixty.football

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.io.File
import java.util.Collections
import java.util.concurrent.Executors

/** Loads club badges and player photos with memory + disk caching. */
object Images {
    private lateinit var dir: File
    private val pool = Executors.newFixedThreadPool(4)
    private val main = Handler(Looper.getMainLooper())
    private val failed: MutableSet<String> = Collections.synchronizedSet(HashSet<String>())
    private val memory = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 1024 / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    fun init(ctx: Context) {
        dir = File(ctx.cacheDir, "img").apply { mkdirs() }
    }

    fun load(view: ImageView, url: String?, placeholder: Int) {
        view.setTag(R.id.img_url, url)
        if (url == null || url.isBlank() || failed.contains(url)) {
            view.setImageResource(placeholder)
            return
        }
        val cached = memory.get(url)
        if (cached != null) {
            view.setImageBitmap(cached)
            return
        }
        view.setImageResource(placeholder)
        pool.execute {
            val bmp = fetch(url)
            if (bmp == null) failed.add(url) else memory.put(url, bmp)
            main.post {
                if (bmp != null && view.getTag(R.id.img_url) == url) view.setImageBitmap(bmp)
            }
        }
    }

    // TheSportsDB serves smaller renditions at "<url>/medium"; fall back to the original.
    private fun candidates(url: String): List<String> =
        if (url.contains("thesportsdb.com/images") && !url.endsWith("/medium") && !url.endsWith("/small") && !url.endsWith("/tiny")) {
            listOf("$url/medium", url)
        } else {
            listOf(url)
        }

    private fun fetch(url: String): Bitmap? {
        for (u in candidates(url)) {
            try {
                val file = File(dir, Net.hash(u))
                val bytes = if (file.exists()) file.readBytes() else Net.download(u).also { file.writeBytes(it) }
                val bmp = decode(bytes)
                if (bmp != null) return bmp
            } catch (e: Exception) {
                // try the next candidate
            }
        }
        return null
    }

    private fun decode(bytes: ByteArray): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0) return null
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 200 && bounds.outHeight / (sample * 2) >= 200) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
    }
}
