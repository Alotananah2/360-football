package com.threesixty.football

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

class HttpException(val code: Int) : IOException("HTTP $code")

/** Tiny HTTP client with a disk cache, so the app is fast and still works offline. */
object Net {
    private lateinit var dir: File

    fun init(ctx: Context) {
        dir = File(ctx.cacheDir, "espn").apply { mkdirs() }
    }

    suspend fun get(url: String, ttlMs: Long, force: Boolean): String {
        val f = File(dir, hash(url))
        if (!force && f.exists() && System.currentTimeMillis() - f.lastModified() < ttlMs) {
            return f.readText()
        }
        return try {
            val body = withContext(Dispatchers.IO) { String(download(url), Charsets.UTF_8) }
            f.writeText(body)
            body
        } catch (e: IOException) {
            // Offline or server trouble: fall back to the last copy we have.
            if (f.exists()) f.readText() else throw e
        }
    }

    fun download(url: String): ByteArray {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 20_000
        conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) 360-Football/2.0")
        try {
            val code = conn.responseCode
            if (code != HttpURLConnection.HTTP_OK) throw HttpException(code)
            return conn.inputStream.use { it.readBytes() }
        } finally {
            conn.disconnect()
        }
    }

    fun clear() {
        dir.listFiles()?.forEach { it.delete() }
    }

    fun hash(s: String): String =
        MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
}
