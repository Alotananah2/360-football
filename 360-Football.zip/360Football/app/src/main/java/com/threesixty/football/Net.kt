package com.threesixty.football

import android.content.Context
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

class HttpException(val code: Int) : IOException("HTTP $code")

/** Tiny HTTP client with a disk cache, so the app is fast and still works offline. */
object Net {
    private lateinit var dir: File

    fun init(ctx: Context) {
        dir = File(ctx.cacheDir, "api").apply { mkdirs() }
    }

    fun get(url: String, ttlMs: Long, force: Boolean): String {
        val file = File(dir, hash(url))
        if (!force && file.exists() && System.currentTimeMillis() - file.lastModified() < ttlMs) {
            return file.readText()
        }
        return try {
            val body = String(download(url), Charsets.UTF_8)
            file.writeText(body)
            body
        } catch (e: IOException) {
            // Offline or rate-limited: fall back to the last copy we have.
            if (file.exists()) file.readText() else throw e
        }
    }

    fun download(url: String): ByteArray {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 20_000
        conn.setRequestProperty("User-Agent", "360-Football/1.0 (Android)")
        try {
            val code = conn.responseCode
            if (code != HttpURLConnection.HTTP_OK) throw HttpException(code)
            return conn.inputStream.use { it.readBytes() }
        } finally {
            conn.disconnect()
        }
    }

    fun clear() {
        dir.listFiles()?.forEach { it.delete() }
    }

    fun hash(s: String): String =
        MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
}
