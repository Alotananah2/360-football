package com.threesixty.football

import android.content.Context
import android.text.format.DateFormat
import java.time.Instant
import java.time.LocalDate
import java.time.Period
import java.time.ZoneId
import java.time.format.DateTimeFormatter

object Format {
    private val zone: ZoneId get() = ZoneId.systemDefault()
    private val longDayFmt = DateTimeFormatter.ofPattern("EEEE d MMMM")
    private val shortDayFmt = DateTimeFormatter.ofPattern("EEE d MMM")
    private val fullDateFmt = DateTimeFormatter.ofPattern("d MMMM yyyy")

    fun localDate(m: Match): LocalDate? = m.kickoff?.atZone(zone)?.toLocalDate()

    fun time(ctx: Context, i: Instant): String {
        val pattern = if (DateFormat.is24HourFormat(ctx)) "HH:mm" else "h:mm a"
        return DateTimeFormatter.ofPattern(pattern).format(i.atZone(zone))
    }

    fun dayHeader(ctx: Context, d: LocalDate?): String {
        if (d == null) return ctx.getString(R.string.date_tbc)
        val today = LocalDate.now(zone)
        return when (d) {
            today -> ctx.getString(R.string.today)
            today.plusDays(1) -> ctx.getString(R.string.tomorrow)
            today.minusDays(1) -> ctx.getString(R.string.yesterday)
            else -> longDayFmt.format(d)
        }
    }

    fun shortDay(d: LocalDate): String = shortDayFmt.format(d)

    /** "Sat 8 Nov 2026 · 20:00" in the phone's time zone. */
    fun kickoff(ctx: Context, m: Match): String? {
        val d = localDate(m) ?: return null
        val day = fullDateFmt.format(d)
        val k = m.kickoff
        return if (k != null) "$day · ${time(ctx, k)}" else day
    }

    fun born(dateBorn: String?): String? {
        if (dateBorn == null) return null
        val d = try {
            LocalDate.parse(dateBorn.take(10))
        } catch (e: Exception) {
            return null
        }
        val age = Period.between(d, LocalDate.now()).years
        return "${fullDateFmt.format(d)} (age $age)"
    }
}
