package com.threesixty.football

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.appbar.MaterialToolbar
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import java.io.IOException

/** One screen for a team, a player, a match or search results. */
class DetailActivity : AppCompatActivity() {

    companion object {
        private const val EXTRA_MODE = "mode"
        private const val EXTRA_ID = "id"
        private const val EXTRA_TITLE = "title"
        private const val TEAM = "team"
        private const val PLAYER = "player"
        private const val MATCH = "match"
        private const val SEARCH = "search"

        private fun open(ctx: Context, mode: String, id: String, title: String?) {
            ctx.startActivity(
                Intent(ctx, DetailActivity::class.java)
                    .putExtra(EXTRA_MODE, mode)
                    .putExtra(EXTRA_ID, id)
                    .putExtra(EXTRA_TITLE, title),
            )
        }

        fun openTeam(ctx: Context, id: String, name: String?) = open(ctx, TEAM, id, name)
        fun openPlayer(ctx: Context, id: String, name: String?) = open(ctx, PLAYER, id, name)
        fun openMatch(ctx: Context, id: String, title: String?) = open(ctx, MATCH, id, title)
        fun openSearch(ctx: Context, query: String) = open(ctx, SEARCH, query, query)

        private const val STAFF = 5
        private val GROUP_NAMES = intArrayOf(
            R.string.g_goalkeepers, R.string.g_defenders, R.string.g_midfielders,
            R.string.g_forwards, R.string.g_players, R.string.g_staff,
        )
    }

    private lateinit var adapter: RowAdapter
    private lateinit var toolbar: MaterialToolbar
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var list: RecyclerView
    private lateinit var empty: TextView
    private lateinit var progress: View

    private var mode = TEAM
    private var id = ""
    private var team: Team? = null
    private var job: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_detail)
        Ui.applyInsets(findViewById(R.id.root))

        mode = intent.getStringExtra(EXTRA_MODE) ?: TEAM
        id = intent.getStringExtra(EXTRA_ID) ?: ""

        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = when (mode) {
            SEARCH -> getString(R.string.search_results_for, id)
            else -> intent.getStringExtra(EXTRA_TITLE) ?: getString(R.string.app_name)
        }

        swipe = findViewById(R.id.swipe)
        list = findViewById(R.id.list)
        empty = findViewById(R.id.empty)
        progress = findViewById(R.id.progress)

        adapter = RowAdapter(this)
        list.layoutManager = adapter.layoutManager()
        list.adapter = adapter
        swipe.setColorSchemeResources(R.color.pitch)
        swipe.setOnChildScrollUpCallback { _, _ -> list.canScrollVertically(-1) }
        swipe.setOnRefreshListener { load(force = true) }

        load()
    }

    private fun load(force: Boolean = false) {
        job?.cancel()
        empty.visibility = View.GONE
        if (!force) progress.visibility = View.VISIBLE
        job = lifecycleScope.launch {
            try {
                val rows = when (mode) {
                    TEAM -> teamRows(force)
                    PLAYER -> playerRows(force)
                    MATCH -> matchRows(force)
                    else -> searchRows(force)
                }
                adapter.submit(rows)
                if (rows.isEmpty()) {
                    empty.text = getString(R.string.no_results)
                    empty.visibility = View.VISIBLE
                }
                invalidateOptionsMenu()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                empty.text = Ui.errorText(this@DetailActivity, e)
                empty.visibility = View.VISIBLE
            } finally {
                progress.visibility = View.GONE
                swipe.isRefreshing = false
            }
        }
    }

    private suspend fun <T> optional(block: suspend () -> List<T>): List<T> = try {
        block()
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        emptyList()
    }

    // ------------------------------------------------------------------ team

    private suspend fun teamRows(force: Boolean): List<Row> = coroutineScope {
        val nextJob = async { optional { Api.teamFixtures(id, force) } }
        val lastJob = async { optional { Api.teamResults(id, force) } }
        val t = Api.team(id, force) ?: throw IOException("Team not found")
        val players = optional { Api.squad(t, force) }
        val next = nextJob.await()
        val last = lastJob.await()
        team = t
        title = t.name

        val rows = ArrayList<Row>()
        rows.add(
            Row.Hero(
                title = t.name,
                sub = t.standing ?: t.location,
                image = t.badge,
                banner = null,
                placeholder = R.drawable.ic_shield_placeholder,
            ),
        )
        t.record?.let { rows.add(Row.Fact(getString(R.string.f_record), it)) }
        t.venue?.let { rows.add(Row.Fact(getString(R.string.f_stadium), it)) }
        t.location?.let { rows.add(Row.Fact(getString(R.string.f_location), it)) }

        if (next.isNotEmpty()) {
            rows.add(Row.Header(getString(R.string.next_matches)))
            next.take(5).forEach { rows.add(Row.MatchItem(it, showDate = true, showLeague = true)) }
        }
        if (last.isNotEmpty()) {
            rows.add(Row.Header(getString(R.string.recent_results)))
            last.take(5).forEach { rows.add(Row.MatchItem(it, showDate = true, showLeague = true)) }
        }

        rows.add(Row.Header(getString(R.string.squad_count, players.size)))
        if (players.isEmpty()) {
            rows.add(Row.Text(getString(R.string.squad_unavailable)))
        } else {
            players.groupBy { squadGroup(it.position) }.toSortedMap().forEach { (group, members) ->
                rows.add(Row.Header(getString(GROUP_NAMES[group]), getString(R.string.n_people, members.size)))
                members.sortedBy { it.number?.toIntOrNull() ?: 999 }.forEach { rows.add(Row.PlayerItem(it)) }
            }
        }
        rows
    }

    private fun squadGroup(position: String?): Int {
        val p = position?.lowercase() ?: return 4
        return when {
            listOf("manager", "coach", "director", "assistant").any { it in p } -> STAFF
            "goal" in p || p == "g" || p == "gk" -> 0
            "midfield" in p || p == "m" -> 2
            "back" in p || "defen" in p || p == "d" -> 1
            "forward" in p || "striker" in p || "wing" in p || "attack" in p || p == "f" -> 3
            else -> 4
        }
    }

    // ------------------------------------------------------------------ player

    private suspend fun playerRows(force: Boolean): List<Row> {
        val p = Api.player(id, force) ?: throw IOException("Player not found")
        title = p.name
        val rows = ArrayList<Row>()
        rows.add(
            Row.Hero(
                title = p.name,
                sub = listOfNotNull(p.position, p.team).joinToString(" · ").ifEmpty { null },
                image = p.photo,
                banner = null,
                placeholder = R.drawable.ic_person,
            ),
        )
        val teamName = p.team
        val teamId = p.teamId
        if (teamName != null) {
            val open: (() -> Unit)? = if (teamId != null) {
                { openTeam(this, teamId, teamName) }
            } else {
                null
            }
            rows.add(Row.Fact(getString(R.string.f_club), teamName, open))
        }
        p.position?.let { rows.add(Row.Fact(getString(R.string.f_position), it)) }
        p.number?.let { rows.add(Row.Fact(getString(R.string.f_number), it)) }
        p.nationality?.let { rows.add(Row.Fact(getString(R.string.f_nationality), it)) }
        val born = Format.born(p.born) ?: p.born?.let { b -> p.age?.let { "$b (age $it)" } ?: b }
        if (born != null) {
            rows.add(Row.Fact(getString(R.string.f_born), born))
        } else {
            p.age?.let { rows.add(Row.Fact(getString(R.string.f_age), it)) }
        }
        p.height?.let { rows.add(Row.Fact(getString(R.string.f_height), it)) }
        p.weight?.let { rows.add(Row.Fact(getString(R.string.f_weight), it)) }
        if (p.stats.isNotEmpty()) {
            rows.add(Row.Header(p.statsTitle ?: getString(R.string.season_stats)))
            p.stats.forEach { (label, value) -> rows.add(Row.Fact(label, value)) }
        }
        return rows
    }

    // ------------------------------------------------------------------ match

    private suspend fun matchRows(force: Boolean): List<Row> {
        val d = Api.match(id, force) ?: throw IOException("Match not found")
        val m = d.match
        title = "${m.home} v ${m.away}"
        val rows = ArrayList<Row>()
        rows.add(Row.Score(m))

        if (d.events.isNotEmpty()) {
            rows.add(Row.Header(getString(R.string.goals_cards)))
            d.events.forEach { e ->
                val icon = when {
                    e.kind.contains("red", ignoreCase = true) -> "🟥"
                    e.kind.contains("yellow", ignoreCase = true) -> "🟨"
                    e.kind.contains("miss", ignoreCase = true) || e.kind.contains("saved", ignoreCase = true) -> "✖"
                    else -> "⚽"
                }
                val side = if (e.home) m.home else m.away
                val extra = when {
                    e.kind.contains("own", ignoreCase = true) -> " (OG)"
                    e.kind.contains("penalty", ignoreCase = true) && icon == "⚽" -> " (pen)"
                    else -> ""
                }
                rows.add(Row.Fact(e.minute, "$icon ${e.text}$extra · $side"))
            }
        }

        m.league?.let { rows.add(Row.Fact(getString(R.string.f_competition), it)) }
        Format.kickoff(this, m)?.let { rows.add(Row.Fact(getString(R.string.f_kickoff), it)) }
        d.venue?.let { rows.add(Row.Fact(getString(R.string.f_venue), it)) }
        d.referee?.let { rows.add(Row.Fact(getString(R.string.f_referee), it)) }
        d.attendance?.let { rows.add(Row.Fact(getString(R.string.f_attendance), it)) }

        for (l in d.lineups) {
            val title = if (l.formation != null) getString(R.string.lineup_formation, l.team, l.formation) else getString(R.string.lineup, l.team)
            rows.add(Row.Header(title))
            l.players.filter { it.starter }.forEach { rows.add(Row.PlayerItem(it)) }
            val subs = l.players.filter { !it.starter }
            if (subs.isNotEmpty()) {
                rows.add(Row.Header(getString(R.string.substitutes), getString(R.string.n_people, subs.size)))
                subs.forEach { rows.add(Row.PlayerItem(it)) }
            }
        }

        val homeId = m.homeId
        val awayId = m.awayId
        if (homeId != null) rows.add(Row.Action(getString(R.string.view_team, m.home)) { openTeam(this, homeId, m.home) })
        if (awayId != null) rows.add(Row.Action(getString(R.string.view_team, m.away)) { openTeam(this, awayId, m.away) })
        return rows
    }

    // ------------------------------------------------------------------ search

    private suspend fun searchRows(force: Boolean): List<Row> {
        val r = Api.search(id, force)
        val rows = ArrayList<Row>()
        if (r.teams.isNotEmpty()) {
            rows.add(Row.Header(getString(R.string.clubs_count, r.teams.size)))
            r.teams.forEach { rows.add(Row.TeamItem(it)) }
        }
        if (r.players.isNotEmpty()) {
            rows.add(Row.Header(getString(R.string.players_count, r.players.size)))
            r.players.forEach { rows.add(Row.PlayerItem(it)) }
        }
        return rows
    }

    // ------------------------------------------------------------------ favourite star

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        if (mode == TEAM) menuInflater.inflate(R.menu.detail, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        val item = menu.findItem(R.id.action_fav)
        val t = team
        if (item != null) {
            item.isVisible = t != null
            if (t != null) {
                val fav = Favourites.contains(t.id)
                item.setIcon(if (fav) R.drawable.ic_star else R.drawable.ic_star_border)
                item.title = getString(if (fav) R.string.unfollow else R.string.follow)
            }
        }
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
                return true
            }
            R.id.action_fav -> {
                val t = team ?: return true
                val added = Favourites.toggle(t)
                Toast.makeText(
                    this,
                    getString(if (added) R.string.followed else R.string.unfollowed, t.name),
                    Toast.LENGTH_SHORT,
                ).show()
                invalidateOptionsMenu()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}
