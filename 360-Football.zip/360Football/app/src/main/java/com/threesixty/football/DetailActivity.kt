package com.threesixty.football

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.appbar.MaterialToolbar
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException

suspend fun <T> io(block: () -> T): T = withContext(Dispatchers.IO) { block() }

/** One screen for a team, a player, a match or search results. */
class DetailActivity : AppCompatActivity() {

    companion object {
        private const val EXTRA_MODE = "mode"
        private const val EXTRA_ID = "id"
        private const val EXTRA_TITLE = "title"
        private const val TEAM = "team"
        private const val PLAYER = "player"
        private const val MATCH = "match"
        private const val SEARCH = "search"

        private fun open(ctx: Context, mode: String, id: String, title: String?) {
            ctx.startActivity(
                Intent(ctx, DetailActivity::class.java)
                    .putExtra(EXTRA_MODE, mode)
                    .putExtra(EXTRA_ID, id)
                    .putExtra(EXTRA_TITLE, title),
            )
        }

        fun openTeam(ctx: Context, id: String, name: String?) = open(ctx, TEAM, id, name)
        fun openPlayer(ctx: Context, id: String, name: String?) = open(ctx, PLAYER, id, name)
        fun openMatch(ctx: Context, id: String, title: String?) = open(ctx, MATCH, id, title)
        fun openSearch(ctx: Context, query: String) = open(ctx, SEARCH, query, query)
    }

    private lateinit var adapter: RowAdapter
    private lateinit var toolbar: MaterialToolbar
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var list: RecyclerView
    private lateinit var empty: TextView
    private lateinit var progress: ProgressBar

    private var mode = TEAM
    private var id = ""
    private var team: Team? = null
    private var job: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_detail)
        Ui.applyInsets(findViewById(R.id.root))

        mode = intent.getStringExtra(EXTRA_MODE) ?: TEAM
        id = intent.getStringExtra(EXTRA_ID) ?: ""

        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = when (mode) {
            SEARCH -> getString(R.string.search_results_for, id)
            else -> intent.getStringExtra(EXTRA_TITLE) ?: getString(R.string.app_name)
        }

        swipe = findViewById(R.id.swipe)
        list = findViewById(R.id.list)
        empty = findViewById(R.id.empty)
        progress = findViewById(R.id.progress)

        adapter = RowAdapter(this)
        list.layoutManager = adapter.layoutManager()
        list.adapter = adapter
        swipe.setColorSchemeResources(R.color.pitch)
        swipe.setOnChildScrollUpCallback { _, _ -> list.canScrollVertically(-1) }
        swipe.setOnRefreshListener { load(force = true) }

        load()
    }

    private fun load(force: Boolean = false) {
        job?.cancel()
        empty.visibility = View.GONE
        if (!force) progress.visibility = View.VISIBLE
        job = lifecycleScope.launch {
            try {
                val rows = when (mode) {
                    TEAM -> teamRows(force)
                    PLAYER -> playerRows(force)
                    MATCH -> matchRows(force)
                    else -> searchRows(force)
                }
                adapter.submit(rows)
                if (rows.isEmpty()) {
                    empty.text = getString(R.string.no_results)
                    empty.visibility = View.VISIBLE
                }
                invalidateOptionsMenu()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                empty.text = Ui.errorText(this@DetailActivity, e)
                empty.visibility = View.VISIBLE
            } finally {
                progress.visibility = View.GONE
                swipe.isRefreshing = false
            }
        }
    }

    // ------------------------------------------------------------------ team

    private suspend fun teamRows(force: Boolean): List<Row> = coroutineScope {
        val nextJob = async(Dispatchers.IO) { runCatching { Api.teamNext(id, force) }.getOrDefault(emptyList()) }
        val lastJob = async(Dispatchers.IO) { runCatching { Api.teamLast(id, force) }.getOrDefault(emptyList()) }
        val t = io { Api.team(id, force) } ?: throw IOException("Team not found")
        val players = io { runCatching { Api.players(t, force) }.getOrDefault(emptyList()) }
        val next = nextJob.await()
        val last = lastJob.await()
        team = t
        title = t.name

        val rows = ArrayList<Row>()
        rows.add(
            Row.Hero(
                title = t.name,
                sub = listOfNotNull(t.league, t.country).joinToString(" · ").ifEmpty { null },
                image = t.badge,
                banner = t.banner,
                placeholder = R.drawable.ic_shield_placeholder,
            ),
        )
        t.stadium?.let { rows.add(Row.Fact(getString(R.string.f_stadium), it)) }
        t.capacity?.takeIf { it != "0" }?.let { rows.add(Row.Fact(getString(R.string.f_capacity), it)) }
        t.location?.let { rows.add(Row.Fact(getString(R.string.f_location), it)) }
        t.formed?.takeIf { it != "0" }?.let { rows.add(Row.Fact(getString(R.string.f_founded), it)) }
        t.website?.let { site -> rows.add(Row.Fact(getString(R.string.f_website), site) { Ui.openUrl(this@DetailActivity, site) }) }

        if (next.isNotEmpty()) {
            rows.add(Row.Header(getString(R.string.next_matches)))
            next.take(5).forEach { rows.add(Row.MatchItem(it, showDate = true, showLeague = true)) }
        }
        if (last.isNotEmpty()) {
            rows.add(Row.Header(getString(R.string.recent_results)))
            last.take(5).forEach { rows.add(Row.MatchItem(it, showDate = true, showLeague = true)) }
        }

        rows.add(Row.Header(getString(R.string.squad_count, players.count { squadGroup(it.position) != STAFF })))
        if (players.isEmpty()) {
            rows.add(Row.Text(getString(R.string.squad_unavailable)))
        } else {
            players.groupBy { squadGroup(it.position) }.toSortedMap().forEach { (group, members) ->
                rows.add(Row.Header(getString(GROUP_NAMES[group]), getString(R.string.n_people, members.size)))
                members.sortedBy { it.number?.toIntOrNull() ?: 999 }.forEach { rows.add(Row.PlayerItem(it)) }
            }
        }

        t.description?.let {
            rows.add(Row.Header(getString(R.string.about_club)))
            rows.add(Row.Text(it))
        }
        rows
    }

    private val STAFF = 5
    private val GROUP_NAMES = intArrayOf(
        R.string.g_goalkeepers, R.string.g_defenders, R.string.g_midfielders,
        R.string.g_forwards, R.string.g_players, R.string.g_staff,
    )

    private fun squadGroup(position: String?): Int {
        val p = position?.lowercase() ?: return 4
        return when {
            listOf("manager", "coach", "director", "assistant", "physio", "analyst", "chairman").any { it in p } -> STAFF
            "goal" in p -> 0
            "midfield" in p -> 2
            "back" in p || "defen" in p -> 1
            "forward" in p || "striker" in p || "wing" in p || "attack" in p -> 3
            else -> 4
        }
    }

    // ------------------------------------------------------------------ player

    private suspend fun playerRows(force: Boolean): List<Row> {
        val p = io { Api.player(id, force) } ?: throw IOException("Player not found")
        title = p.name
        val rows = ArrayList<Row>()
        rows.add(
            Row.Hero(
                title = p.name,
                sub = listOfNotNull(p.position, p.team).joinToString(" · ").ifEmpty { null },
                image = p.photo,
                banner = p.banner,
                placeholder = R.drawable.ic_person,
            ),
        )
        val teamName = p.team
        val teamId = p.teamId
        if (teamName != null) {
            val open: (() -> Unit)? = if (teamId != null) {
                { DetailActivity.openTeam(this, teamId, teamName) }
            } else {
                null
            }
            rows.add(Row.Fact(getString(R.string.f_club), teamName, open))
        }
        p.position?.let { rows.add(Row.Fact(getString(R.string.f_position), it)) }
        p.number?.let { rows.add(Row.Fact(getString(R.string.f_number), it)) }
        p.nationality?.let { rows.add(Row.Fact(getString(R.string.f_nationality), it)) }
        Format.born(p.born)?.let { rows.add(Row.Fact(getString(R.string.f_born), it)) }
        p.birthPlace?.let { rows.add(Row.Fact(getString(R.string.f_birthplace), it)) }
        p.height?.let { rows.add(Row.Fact(getString(R.string.f_height), it)) }
        p.weight?.let { rows.add(Row.Fact(getString(R.string.f_weight), it)) }
        p.foot?.let { rows.add(Row.Fact(getString(R.string.f_foot), it)) }
        p.description?.let {
            rows.add(Row.Header(getString(R.string.biography)))
            rows.add(Row.Text(it))
        }
        return rows
    }

    // ------------------------------------------------------------------ match

    private suspend fun matchRows(force: Boolean): List<Row> {
        val m = io { Api.event(id, force) } ?: throw IOException("Match not found")
        title = "${m.home} v ${m.away}"
        val rows = ArrayList<Row>()
        rows.add(Row.Score(m))
        m.league?.let { rows.add(Row.Fact(getString(R.string.f_competition), it)) }
        m.round?.takeIf { it != "0" }?.let { rows.add(Row.Fact(getString(R.string.f_round), it)) }
        Format.kickoff(this, m)?.let { rows.add(Row.Fact(getString(R.string.f_kickoff), it)) }
        m.venue?.let { rows.add(Row.Fact(getString(R.string.f_venue), it)) }
        m.referee?.let { rows.add(Row.Fact(getString(R.string.f_referee), it)) }
        m.spectators?.takeIf { it != "0" }?.let { rows.add(Row.Fact(getString(R.string.f_attendance), it)) }
        m.season?.let { rows.add(Row.Fact(getString(R.string.f_season), it)) }
        val homeId = m.homeId
        val awayId = m.awayId
        if (homeId != null) rows.add(Row.Action(getString(R.string.view_team, m.home)) { openTeam(this, homeId, m.home) })
        if (awayId != null) rows.add(Row.Action(getString(R.string.view_team, m.away)) { openTeam(this, awayId, m.away) })
        m.video?.let { url -> rows.add(Row.Action(getString(R.string.watch_highlights)) { Ui.openUrl(this, url) }) }
        m.description?.let {
            rows.add(Row.Header(getString(R.string.match_report)))
            rows.add(Row.Text(it))
        }
        return rows
    }

    // ------------------------------------------------------------------ search

    private suspend fun searchRows(force: Boolean): List<Row> = coroutineScope {
        val teamsJob = async(Dispatchers.IO) { runCatching { Api.searchTeams(id, force) } }
        val playersJob = async(Dispatchers.IO) { runCatching { Api.searchPlayers(id, force) } }
        val teamsResult = teamsJob.await()
        val playersResult = playersJob.await()
        if (teamsResult.isFailure && playersResult.isFailure) {
            throw teamsResult.exceptionOrNull() ?: IOException("Search failed")
        }
        val teams = teamsResult.getOrDefault(emptyList())
        val players = playersResult.getOrDefault(emptyList())
        val rows = ArrayList<Row>()
        if (teams.isNotEmpty()) {
            rows.add(Row.Header(getString(R.string.clubs_count, teams.size)))
            teams.forEach { rows.add(Row.TeamItem(it)) }
        }
        if (players.isNotEmpty()) {
            rows.add(Row.Header(getString(R.string.players_count, players.size)))
            players.forEach { rows.add(Row.PlayerItem(it)) }
        }
        rows
    }

    // ------------------------------------------------------------------ favourite star

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        if (mode == TEAM) menuInflater.inflate(R.menu.detail, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        val item = menu.findItem(R.id.action_fav)
        val t = team
        if (item != null) {
            item.isVisible = t != null
            if (t != null) {
                val fav = Favourites.contains(t.id)
                item.setIcon(if (fav) R.drawable.ic_star else R.drawable.ic_star_border)
                item.title = getString(if (fav) R.string.unfollow else R.string.follow)
            }
        }
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
                return true
            }
            R.id.action_fav -> {
                val t = team ?: return true
                val added = Favourites.toggle(t)
                Toast.makeText(
                    this,
                    getString(if (added) R.string.followed else R.string.unfollowed, t.name),
                    Toast.LENGTH_SHORT,
                ).show()
                invalidateOptionsMenu()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}
