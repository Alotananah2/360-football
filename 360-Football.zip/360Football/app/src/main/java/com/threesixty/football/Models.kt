package com.threesixty.football

import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import kotlin.math.roundToInt

// ------------------------------------------------------------------ JSON helpers

/** First non-blank string among [keys], or null. */
fun JSONObject.str(vararg keys: String): String? {
    for (k in keys) {
        if (!has(k) || isNull(k)) continue
        val v = opt(k) ?: continue
        if (v is JSONObject) continue
        val s = v.toString().trim()
        if (s.isNotEmpty() && s != "null") return s
    }
    return null
}

fun JSONObject.obj(key: String): JSONObject? = optJSONObject(key)

fun JSONObject.list(key: String): List<JSONObject> {
    val arr = optJSONArray(key) ?: return emptyList()
    return (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
}

/** Team logo from either `logo` or the first of `logos`. */
fun JSONObject.logo(): String? = str("logo") ?: list("logos").firstOrNull()?.str("href")

/** ESPN times look like 2026-11-07T13:00Z (no seconds). */
fun parseInstant(s: String?): Instant? {
    if (s.isNullOrBlank()) return null
    val fixed = if (Regex("""\d{4}-\d\d-\d\dT\d\d:\d\dZ""").matches(s)) s.dropLast(1) + ":00Z" else s
    return try {
        Instant.parse(fixed)
    } catch (e: Exception) {
        null
    }
}

fun parseDay(s: String?): LocalDate? {
    if (s == null || s.length < 10) return null
    return try {
        LocalDate.parse(s.take(10))
    } catch (e: Exception) {
        null
    }
}

// ------------------------------------------------------------------ leagues

/** [id] is ESPN's league code. */
data class League(val id: String, val name: String)

object Leagues {
    const val FAVOURITES = "fav"

    val all = listOf(
        League("esp.1", "La Liga"),
        League("eng.1", "Premier League"),
        League("ksa.1", "Saudi Pro League"),
        League("uefa.champions", "Champions League"),
        League("ita.1", "Serie A"),
        League("ger.1", "Bundesliga"),
        League("fra.1", "Ligue 1"),
        League("uefa.europa", "Europa League"),
        League("ned.1", "Eredivisie"),
        League("por.1", "Primeira Liga"),
        League("usa.1", "MLS"),
    )

    fun byId(id: String): League? = all.firstOrNull { it.id == id }
}

// ------------------------------------------------------------------ matches

data class Goal(val minute: String, val player: String, val home: Boolean, val note: String?)

data class Match(
    val id: String,
    val league: String?,
    val home: String,
    val away: String,
    val homeId: String?,
    val awayId: String?,
    val homeScore: String?,
    val awayScore: String?,
    val homeBadge: String?,
    val awayBadge: String?,
    val kickoff: Instant?,
    val venue: String?,
    /** "pre", "in" or "post". */
    val state: String,
    val statusText: String?,
    val clock: String?,
    val postponed: Boolean,
    val attendance: String?,
    val goals: List<Goal>,
) {
    val hasScore: Boolean get() = state != "pre" && !postponed && homeScore != null && awayScore != null
    val isLive: Boolean get() = state == "in" && !postponed
    val isFinished: Boolean get() = state == "post" && !postponed
    val isPostponed: Boolean get() = postponed
    val sortKey: Long get() = kickoff?.epochSecond ?: Long.MAX_VALUE

    companion object {
        private fun score(c: JSONObject): String? = when (val o = c.opt("score")) {
            null -> null
            is JSONObject -> o.str("displayValue", "value")
            else -> o.toString().trim().takeIf { it.isNotEmpty() && it != "null" }
        }

        /**
         * Builds a match from a scoreboard/schedule event ([event]) or a match summary header
         * (pass the header as [event] and its first competition as [comp]).
         */
        fun from(event: JSONObject, leagueName: String?, comp: JSONObject? = null): Match? {
            val c = comp ?: event.list("competitions").firstOrNull() ?: return null
            val competitors = c.list("competitors")
            val h = competitors.firstOrNull { it.str("homeAway") == "home" } ?: competitors.getOrNull(0) ?: return null
            val a = competitors.firstOrNull { it.str("homeAway") == "away" } ?: competitors.getOrNull(1) ?: return null
            val ht = h.obj("team") ?: return null
            val at = a.obj("team") ?: return null
            val id = event.str("id") ?: c.str("id") ?: return null

            val status = event.obj("status") ?: c.obj("status")
            val type = status?.obj("type")
            val typeName = type?.str("name") ?: ""
            val postponed = listOf("POSTPONED", "CANCELED", "CANCELLED", "ABANDONED", "SUSPENDED", "DELAYED")
                .any { typeName.contains(it) }

            val homeId = ht.str("id")
            val goals = c.list("details").filter { it.optBoolean("scoringPlay") }.mapNotNull { d ->
                val player = d.list("athletesInvolved").firstOrNull()?.str("shortName", "displayName") ?: return@mapNotNull null
                val note = when {
                    d.optBoolean("ownGoal") -> "OG"
                    d.optBoolean("penaltyKick") -> "pen"
                    else -> null
                }
                Goal(
                    minute = d.obj("clock")?.str("displayValue") ?: "",
                    player = player,
                    home = d.obj("team")?.str("id") == homeId,
                    note = note,
                )
            }

            val league = leagueName
                ?: event.obj("league")?.str("shortName", "name", "abbreviation")
                ?: event.obj("season")?.str("displayName")

            return Match(
                id = id,
                league = league,
                home = ht.str("displayName", "name") ?: "Home",
                away = at.str("displayName", "name") ?: "Away",
                homeId = homeId,
                awayId = at.str("id"),
                homeScore = score(h),
                awayScore = score(a),
                homeBadge = ht.logo(),
                awayBadge = at.logo(),
                kickoff = parseInstant(event.str("date") ?: c.str("date")),
                venue = c.obj("venue")?.str("fullName"),
                state = type?.str("state") ?: "pre",
                statusText = type?.str("shortDetail", "detail", "description"),
                clock = status?.str("displayClock"),
                postponed = postponed,
                attendance = c.str("attendance")?.takeIf { it != "0" },
                goals = goals,
            )
        }
    }
}

// ------------------------------------------------------------------ tables

data class Standing(
    val rank: String,
    val teamId: String?,
    val team: String,
    val badge: String?,
    val played: String,
    val win: String,
    val draw: String,
    val loss: String,
    val goalDiff: String,
    val points: String,
    val note: String?,
    val noteColor: String?,
) {
    companion object {
        fun from(entry: JSONObject, index: Int): Standing? {
            val t = entry.obj("team") ?: return null
            val stats = HashMap<String, String>()
            entry.list("stats").forEach { s ->
                val name = s.str("name") ?: return@forEach
                stats[name] = s.str("displayValue", "value") ?: ""
            }
            val note = entry.obj("note")
            return Standing(
                rank = stats["rank"]?.takeIf { it.isNotEmpty() && it != "0" } ?: (index + 1).toString(),
                teamId = t.str("id"),
                team = t.str("displayName", "name") ?: return null,
                badge = t.logo(),
                played = stats["gamesPlayed"] ?: "0",
                win = stats["wins"] ?: "0",
                draw = stats["ties"] ?: "0",
                loss = stats["losses"] ?: "0",
                goalDiff = stats["pointDifferential"] ?: "0",
                points = stats["points"] ?: "0",
                note = note?.str("description"),
                noteColor = note?.str("color"),
            )
        }
    }
}

data class TableGroup(val name: String?, val rows: List<Standing>)

// ------------------------------------------------------------------ teams & players

data class Team(
    val id: String,
    val name: String,
    val badge: String? = null,
    val leagueSlug: String? = null,
    val location: String? = null,
    val venue: String? = null,
    val record: String? = null,
    val standing: String? = null,
    val subtitle: String? = null,
)

data class Player(
    val id: String,
    val name: String,
    val team: String? = null,
    val teamId: String? = null,
    val position: String? = null,
    val nationality: String? = null,
    val born: String? = null,
    val age: String? = null,
    val number: String? = null,
    val height: String? = null,
    val weight: String? = null,
    val photo: String? = null,
    val statsTitle: String? = null,
    val stats: List<Pair<String, String>> = emptyList(),
    val starter: Boolean = false,
) {
    companion object {
        fun headshot(id: String) = "https://a.espncdn.com/i/headshots/soccer/players/full/$id.png"

        /** From a team roster entry. */
        fun fromRoster(a: JSONObject, team: Team?): Player? {
            val id = a.str("id") ?: return null
            val name = a.str("displayName", "fullName") ?: return null
            val inches = a.optDouble("height", 0.0)
            val lbs = a.optDouble("weight", 0.0)
            return Player(
                id = id,
                name = name,
                team = team?.name,
                teamId = team?.id,
                position = a.obj("position")?.str("displayName", "name"),
                nationality = a.str("citizenship"),
                born = parseDay(a.str("dateOfBirth"))?.toString(),
                age = a.str("age"),
                number = a.str("jersey"),
                height = if (inches > 0) "${(inches * 2.54).roundToInt()} cm" else a.str("displayHeight"),
                weight = if (lbs > 0) "${(lbs * 0.4536).roundToInt()} kg" else a.str("displayWeight"),
                photo = a.obj("headshot")?.str("href") ?: headshot(id),
            )
        }
    }
}
